﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH_01_Raphael_Christiano
{
    public partial class Form2 : Form
    {

        private string[] words;
        private Random rnd = new Random();

        List<char> kata = new List<char>();
        List<char> tampilan = new List<char>() { '_', '_', '_', '_', '_'};
        public Form2(string[] words)
        {
            InitializeComponent();
            this.words = words;
            int randomIndex = rnd.Next(words.Length);
            lb_game.Text = words[randomIndex];
            string kataRahasia = lb_game.Text;

            foreach (char k in kataRahasia)
            {
                kata.Add(k);
            }          
        }
        private void TebakHuruf(char huruf)
        {
            if (kata.Contains(huruf))
            {
                for (int i = 0; i < kata.Count; i++)
                {
                    if (kata[i] == huruf)
                    {
                        tampilan[i] = huruf;
                    }
                }
            }
            lb_huruf1.Text = tampilan[0].ToString();
            lb_huruf2.Text = tampilan[1].ToString();
            lb_huruf3.Text = tampilan[2].ToString();
            lb_huruf4.Text = tampilan[3].ToString();
            lb_huruf5.Text = tampilan[4].ToString();

            if (lb_huruf1.Text != "_" && lb_huruf2.Text != "_" && lb_huruf3.Text != "_" && lb_huruf4.Text != "_" && lb_huruf5.Text != "_")
            {
                MessageBox.Show("You win!");
            }
        }

        private void btn_q_Click(object sender, EventArgs e)
        {
            char huruf = 'q';
            TebakHuruf(huruf);
        }
        private void btn_w_Click(object sender, EventArgs e)
        {
            char huruf = 'w';
            TebakHuruf(huruf);
        }

        private void btn_e_Click(object sender, EventArgs e)
        {
            char huruf = 'e';
            TebakHuruf(huruf);
        }

        private void btn_r_Click(object sender, EventArgs e)
        {
            char huruf = 'r';
            TebakHuruf(huruf);
        }

        private void btn_t_Click(object sender, EventArgs e)
        {
            char huruf = 't';
            TebakHuruf(huruf);
        }

        private void btn_y_Click(object sender, EventArgs e)
        {
            char huruf = 'y';
            TebakHuruf(huruf);
        }

        private void btn_u_Click(object sender, EventArgs e)
        {
            char huruf = 'u';
            TebakHuruf(huruf);
        }

        private void btn_i_Click(object sender, EventArgs e)
        {
            char huruf = 'i';
            TebakHuruf(huruf);
        }

        private void btn_o_Click(object sender, EventArgs e)
        {
            char huruf = 'o';
            TebakHuruf(huruf);
        }

        private void btn_p_Click(object sender, EventArgs e)
        {
            char huruf = 'p';
            TebakHuruf(huruf);
        }

        private void btn_a_Click(object sender, EventArgs e)
        {
            char huruf = 'a';
            TebakHuruf(huruf);
        }

        private void btn_s_Click(object sender, EventArgs e)
        {
            char huruf = 's';
            TebakHuruf(huruf);
        }

        private void btn_d_Click(object sender, EventArgs e)
        {
            char huruf = 'd';
            TebakHuruf(huruf);
        }

        private void btn_f_Click(object sender, EventArgs e)
        {
            char huruf = 'f';
            TebakHuruf(huruf);
        }

        private void btn_g_Click(object sender, EventArgs e)
        {
            char huruf = 'g';
            TebakHuruf(huruf);
        }

        private void btn_h_Click(object sender, EventArgs e)
        {
            char huruf = 'h';
            TebakHuruf(huruf);
        }

        private void btn_j_Click(object sender, EventArgs e)
        {
            char huruf = 'j';
            TebakHuruf(huruf);
        }

        private void btn_k_Click(object sender, EventArgs e)
        {
            char huruf = 'k';
            TebakHuruf(huruf);
        }

        private void btn_l_Click(object sender, EventArgs e)
        {
            char huruf = 'l';
            TebakHuruf(huruf);
        }

        private void btn_z_Click(object sender, EventArgs e)
        {
            char huruf = 'z';
            TebakHuruf(huruf);
        }

        private void btn_x_Click(object sender, EventArgs e)
        {
            char huruf = 'x';
            TebakHuruf(huruf);
        }

        private void btn_c_Click(object sender, EventArgs e)
        {
            char huruf = 'c';
            TebakHuruf(huruf);
        }

        private void btn_v_Click(object sender, EventArgs e)
        {
            char huruf = 'v';
            TebakHuruf(huruf);
        }

        private void btn_b_Click(object sender, EventArgs e)
        {
            char huruf = 'b';
            TebakHuruf(huruf);
        }

        private void btn_n_Click(object sender, EventArgs e)
        {
            char huruf = 'n';
            TebakHuruf(huruf);
        }

        private void btn_m_Click(object sender, EventArgs e)
        {
            char huruf = 'm';
            TebakHuruf(huruf);
        }
    }
}
