﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH_01_Raphael_Christiano
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void btn_play_Click(object sender, EventArgs e)
        {

            string[] words = new string[5];
            words[0] = tbox_1.Text;
            words[1] = tbox_2.Text;
            words[2] = tbox_3.Text;
            words[3] = tbox_4.Text;
            words[4] = tbox_5.Text;

            bool nomor = false;
            foreach (string word in words)
            {
                foreach (char a in word)
                {
                    if (!char.IsLetter(a))
                    {
                        nomor = true;
                    }
                }
            }
           
            Random rnd = new Random(); 
            for (int i = words.Length - 1; i > 0; i--)
            {
                int j = rnd.Next(0, i + 1);
                string temp = words[i];
                words[i] = words[j];
                words[j] = temp;
            }

            

            if (words[0].Length != 5 || words[1].Length != 5 || words[2].Length != 5 || words[3].Length != 5 || words[4].Length != 5)
            {
                MessageBox.Show("MASI ERROR WOI!!");
            }
            
            else if (words[0] == words[1] || words[0] == words[2] || words[0] == words[3] || words[0] == words[4] || words[1] == words[2] || words[1] == words[3] || words[1] == words[4] || words[2] == words[3] || words[2] == words[4] || words[3] == words[4])
            {
              MessageBox.Show("GABOLE KEMBAR DONG!!");
            }
            else if (nomor)
            {
                MessageBox.Show("GABOLE NOMOR JUGA!!");
            }
            
            else
            {
               MessageBox.Show("PLAY NOW!!");
               Form2 form2 = new Form2(words);
               form2.Show();
               this.Hide();
            }
                
        }
    }
}
