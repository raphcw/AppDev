﻿namespace TH_01_Raphael_Christiano
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_kata1 = new System.Windows.Forms.Label();
            this.lb_kata2 = new System.Windows.Forms.Label();
            this.lb_kata3 = new System.Windows.Forms.Label();
            this.lb_kata4 = new System.Windows.Forms.Label();
            this.lb_kata5 = new System.Windows.Forms.Label();
            this.tbox_1 = new System.Windows.Forms.TextBox();
            this.tbox_2 = new System.Windows.Forms.TextBox();
            this.tbox_3 = new System.Windows.Forms.TextBox();
            this.tbox_4 = new System.Windows.Forms.TextBox();
            this.tbox_5 = new System.Windows.Forms.TextBox();
            this.btn_play = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lb_kata1
            // 
            this.lb_kata1.AutoSize = true;
            this.lb_kata1.Location = new System.Drawing.Point(12, 27);
            this.lb_kata1.Name = "lb_kata1";
            this.lb_kata1.Size = new System.Drawing.Size(53, 16);
            this.lb_kata1.TabIndex = 0;
            this.lb_kata1.Text = "Word 1:";
            // 
            // lb_kata2
            // 
            this.lb_kata2.AutoSize = true;
            this.lb_kata2.Location = new System.Drawing.Point(12, 61);
            this.lb_kata2.Name = "lb_kata2";
            this.lb_kata2.Size = new System.Drawing.Size(53, 16);
            this.lb_kata2.TabIndex = 1;
            this.lb_kata2.Text = "Word 2:";
            // 
            // lb_kata3
            // 
            this.lb_kata3.AutoSize = true;
            this.lb_kata3.Location = new System.Drawing.Point(12, 94);
            this.lb_kata3.Name = "lb_kata3";
            this.lb_kata3.Size = new System.Drawing.Size(53, 16);
            this.lb_kata3.TabIndex = 2;
            this.lb_kata3.Text = "Word 3:";
            // 
            // lb_kata4
            // 
            this.lb_kata4.AutoSize = true;
            this.lb_kata4.Location = new System.Drawing.Point(12, 126);
            this.lb_kata4.Name = "lb_kata4";
            this.lb_kata4.Size = new System.Drawing.Size(53, 16);
            this.lb_kata4.TabIndex = 3;
            this.lb_kata4.Text = "Word 4:";
            // 
            // lb_kata5
            // 
            this.lb_kata5.AutoSize = true;
            this.lb_kata5.Location = new System.Drawing.Point(12, 156);
            this.lb_kata5.Name = "lb_kata5";
            this.lb_kata5.Size = new System.Drawing.Size(53, 16);
            this.lb_kata5.TabIndex = 4;
            this.lb_kata5.Text = "Word 5:";
            // 
            // tbox_1
            // 
            this.tbox_1.Location = new System.Drawing.Point(71, 23);
            this.tbox_1.Name = "tbox_1";
            this.tbox_1.Size = new System.Drawing.Size(100, 22);
            this.tbox_1.TabIndex = 5;
            // 
            // tbox_2
            // 
            this.tbox_2.Location = new System.Drawing.Point(71, 58);
            this.tbox_2.Name = "tbox_2";
            this.tbox_2.Size = new System.Drawing.Size(100, 22);
            this.tbox_2.TabIndex = 6;
            // 
            // tbox_3
            // 
            this.tbox_3.Location = new System.Drawing.Point(71, 92);
            this.tbox_3.Name = "tbox_3";
            this.tbox_3.Size = new System.Drawing.Size(100, 22);
            this.tbox_3.TabIndex = 7;
            // 
            // tbox_4
            // 
            this.tbox_4.Location = new System.Drawing.Point(71, 124);
            this.tbox_4.Name = "tbox_4";
            this.tbox_4.Size = new System.Drawing.Size(100, 22);
            this.tbox_4.TabIndex = 8;
            // 
            // tbox_5
            // 
            this.tbox_5.Location = new System.Drawing.Point(71, 155);
            this.tbox_5.Name = "tbox_5";
            this.tbox_5.Size = new System.Drawing.Size(100, 22);
            this.tbox_5.TabIndex = 9;
            // 
            // btn_play
            // 
            this.btn_play.Location = new System.Drawing.Point(55, 197);
            this.btn_play.Name = "btn_play";
            this.btn_play.Size = new System.Drawing.Size(75, 23);
            this.btn_play.TabIndex = 10;
            this.btn_play.Text = "PLAY!";
            this.btn_play.UseVisualStyleBackColor = true;
            this.btn_play.Click += new System.EventHandler(this.btn_play_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1058, 600);
            this.Controls.Add(this.btn_play);
            this.Controls.Add(this.tbox_5);
            this.Controls.Add(this.tbox_4);
            this.Controls.Add(this.tbox_3);
            this.Controls.Add(this.tbox_2);
            this.Controls.Add(this.tbox_1);
            this.Controls.Add(this.lb_kata5);
            this.Controls.Add(this.lb_kata4);
            this.Controls.Add(this.lb_kata3);
            this.Controls.Add(this.lb_kata2);
            this.Controls.Add(this.lb_kata1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_kata1;
        private System.Windows.Forms.Label lb_kata2;
        private System.Windows.Forms.Label lb_kata3;
        private System.Windows.Forms.Label lb_kata4;
        private System.Windows.Forms.Label lb_kata5;
        private System.Windows.Forms.TextBox tbox_1;
        private System.Windows.Forms.TextBox tbox_2;
        private System.Windows.Forms.TextBox tbox_3;
        private System.Windows.Forms.TextBox tbox_4;
        private System.Windows.Forms.TextBox tbox_5;
        private System.Windows.Forms.Button btn_play;
    }
}

