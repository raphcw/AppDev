﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace TH14_Raphael_Christiano_Wahono
{
    public partial class Form1 : Form
    {
        MySqlConnection connect;
        MySqlCommand command;
        MySqlDataAdapter dataAdapter;
        DataTable dtTeam;
        DataTable dtAway;
        DataTable player;
        DataTable dmatch;
        DataTable dt;
       
        string sqlQuery;
        string idaway;
        string idhome;
        string idteam;
        int index = 0;
        public Form1()
        {
            InitializeComponent();
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            tb_matchid.Enabled = false;
            connect = new MySqlConnection("server = localhost; uid = root;pwd = Raphael0410;database = premier_league");
            dtTeam = new DataTable();
            dtAway = new DataTable();
            sqlQuery = "select team_id, team_name from team t";
            command = new MySqlCommand(sqlQuery, connect);
            dataAdapter = new MySqlDataAdapter(command);
            dataAdapter.Fill(dtTeam);
            dataAdapter.Fill(dtAway);

            cb_home.DataSource = dtTeam;
            cb_home.DisplayMember = "team_name";
            cb_home.ValueMember = "team_id";
            cb_home.SelectedIndex = -1;

            cb_away.DataSource = dtAway;
            cb_away.DisplayMember = "team_name";
            cb_away.ValueMember = "team_id";
            cb_away.SelectedIndex = -1;

            dt = new DataTable();
            dt.Columns.Add("Minute");
            dt.Columns.Add("Team");
            dt.Columns.Add("Player");
            dt.Columns.Add("Type");

            dmatch = new DataTable();
            dmatch.Columns.Add("Match_id");
            dmatch.Columns.Add("Minute");
            dmatch.Columns.Add("Team_id");
            dmatch.Columns.Add("Player_id");
            dmatch.Columns.Add("Type");
            dmatch.Columns.Add("Delete");
        }

        private void bt_add_Click(object sender, EventArgs e)
        {
            dt.Rows.Add(tb_minute.Text, cb_team.Text, cb_player.Text, cb_type.Text);
            
            dgv_1.DataSource = dt;
            dmatch.Rows.Add(tb_matchid.Text, tb_minute.Text, idteam, cb_player.SelectedValue, cb_player.Text, 0);
        }

        private void dtp_1_ValueChanged(object sender, EventArgs e)
        {
            string year = dtp_1.Value.Year.ToString();
            sqlQuery = $"select count(match_id) from `match` where match_id like '{year}%';";
            command = new MySqlCommand(sqlQuery, connect);
            DataTable dtCount = new DataTable();
            dataAdapter = new MySqlDataAdapter(command);
            dataAdapter.Fill(dtCount);

           
            if (Convert.ToInt32(dtCount.Rows[0][0]) < 10)
            {
                tb_matchid.Text = $"{year}00{(Convert.ToInt32(dtCount.Rows[0][0]) + 1).ToString()}";

            }
            
            else if (Convert.ToInt32(dtCount.Rows[0][0]) >= 10 && Convert.ToInt32(dtCount.Rows[0][0]) < 100)
            {
                tb_matchid.Text = $"{year}0{(Convert.ToInt32(dtCount.Rows[0][0]) + 1).ToString()}";
            }
            
            else if (Convert.ToInt32(dtCount.Rows[0][0]) >= 100)
            {
                tb_matchid.Text = $"{year}{(Convert.ToInt32(dtCount.Rows[0][0]) + 1).ToString()}";
            }
        }

        private void cb_home_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_home.SelectedIndex == -1 || cb_away.SelectedIndex == -1)
            {

            }
            else
            {
                if (cb_away.Text == cb_home.Text)
                {
                    MessageBox.Show("Team ga bole sama dek");
                    cb_away.SelectedIndex = -1;
                    cb_home.SelectedIndex = -1;
                }
                else
                {
                    cb_team.Items.Clear();
                    idhome = Convert.ToString(cb_home.SelectedValue);
                    idaway = Convert.ToString(cb_away.SelectedValue);
                    cb_team.Items.Add(cb_home.Text);
                    cb_team.Items.Add(cb_away.Text);
                }
            }
        }

        private void cb_away_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_home.SelectedIndex == -1 || cb_away.SelectedIndex == -1)
            {

            }
            else
            {
                if (cb_away.Text == cb_home.Text)
                {
                    MessageBox.Show("Team Home tidak boleh sama");
                    cb_away.SelectedIndex = -1;
                    cb_home.SelectedIndex = -1;
                }
                else
                {
                    cb_team.Items.Clear();
                    idhome = Convert.ToString(cb_home.SelectedValue);
                    idaway = Convert.ToString(cb_away.SelectedValue);
                    cb_team.Items.Add(cb_home.Text);
                    cb_team.Items.Add(cb_away.Text);
                }
            }
        }

        private void cb_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            player = new DataTable();
            if (cb_team.SelectedIndex == 0)
            {
                idteam = idhome;
            }
            if (cb_team.SelectedIndex == 1)
            {
                idteam = idaway;
            }
            
            sqlQuery = $"select player_id, player_name from player where team_id like '%{idteam}%'";
            command = new MySqlCommand(sqlQuery, connect);
            dataAdapter = new MySqlDataAdapter(command);
            dataAdapter.Fill(player);
           
            cb_player.DataSource = player;
            cb_player.DisplayMember = "player_name";
            cb_player.ValueMember = "player_id";
        }

        private void bt_delete_Click(object sender, EventArgs e)
        {
            dt.Rows.RemoveAt(index);
            dgv_1.DataSource = dt;
            dmatch.Rows.RemoveAt(index);
        }

        private void bt_insert_Click(object sender, EventArgs e)
        {
            bool tanggalBenar = false;
            if (dtp_1.Value.Year == 2016 && dtp_1.Value.Month == 2 && dtp_1.Value.Day >= 14)
            {


                tanggalBenar = true;
            }
            else if (dtp_1.Value.Year == 2016 && dtp_1.Value.Month > 2)
            {
                tanggalBenar = true;
            }
            else if (dtp_1.Value.Year > 2016)
            {
                tanggalBenar = true;
            }
            else
            {

                tanggalBenar = false;
            }

            if (tanggalBenar)
            {
                try
                {
                    connect.Open();
                    for (int i = 0; i < dmatch.Rows.Count; i++)
                    {
                        sqlQuery = $"insert into dmatch values ({dmatch.Rows[i][0]}, {dmatch.Rows[i][1]}, '{dmatch.Rows[i][2]}', '{dmatch.Rows[i][3]}', '{dmatch.Rows[i][4]}', {dmatch.Rows[i][5]});";
                        command = new MySqlCommand(sqlQuery, connect);
                        command.ExecuteNonQuery();
                    }
                }

                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

                int hscore = 0;
                int ascore = 0;
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (dt.Rows[i][1].ToString() == cb_home.Text)
                    {
                        if (dt.Rows[i][3].ToString() == "GO" || dt.Rows[i][3].ToString() == "GP")
                        {
                            hscore++;
                        }
                        else if (dt.Rows[i][3].ToString() == "GW")
                        {
                            ascore++;
                        }
                    }
                    else
                    {
                        if (dt.Rows[i][3].ToString() == "GO" || dt.Rows[i][3].ToString() == "GP")
                        {
                            ascore++;
                        }
                        else if (dt.Rows[i][3].ToString() == "GW")
                        {
                            hscore++;
                        }
                    }
                }
                try
                {
                    sqlQuery = $"insert into `match` values ('{tb_matchid.Text}', '{dtp_1.Value.ToString("yyyy-MM-dd")}', '{idhome}', '{idaway}', {hscore}, {ascore}, 'M002', 0);";
                    command = new MySqlCommand(sqlQuery, connect);
                    command.ExecuteNonQuery();
                    connect.Close();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Tanggalnya ga valid");
            }
        }

        private void dgv_1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            index = e.RowIndex;
        }
    }
 }

