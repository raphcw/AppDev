﻿namespace TH14_Raphael_Christiano_Wahono
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bt_insert = new System.Windows.Forms.Button();
            this.bt_delete = new System.Windows.Forms.Button();
            this.bt_add = new System.Windows.Forms.Button();
            this.cb_type = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tb_minute = new System.Windows.Forms.TextBox();
            this.cb_team = new System.Windows.Forms.ComboBox();
            this.cb_player = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.dgv_1 = new System.Windows.Forms.DataGridView();
            this.dtp_1 = new System.Windows.Forms.DateTimePicker();
            this.cb_away = new System.Windows.Forms.ComboBox();
            this.cb_home = new System.Windows.Forms.ComboBox();
            this.tb_matchid = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_1)).BeginInit();
            this.SuspendLayout();
            // 
            // bt_insert
            // 
            this.bt_insert.Location = new System.Drawing.Point(192, 502);
            this.bt_insert.Margin = new System.Windows.Forms.Padding(2);
            this.bt_insert.Name = "bt_insert";
            this.bt_insert.Size = new System.Drawing.Size(219, 29);
            this.bt_insert.TabIndex = 40;
            this.bt_insert.Text = "Insert";
            this.bt_insert.UseVisualStyleBackColor = true;
            this.bt_insert.Click += new System.EventHandler(this.bt_insert_Click);
            // 
            // bt_delete
            // 
            this.bt_delete.Location = new System.Drawing.Point(806, 368);
            this.bt_delete.Margin = new System.Windows.Forms.Padding(2);
            this.bt_delete.Name = "bt_delete";
            this.bt_delete.Size = new System.Drawing.Size(93, 29);
            this.bt_delete.TabIndex = 39;
            this.bt_delete.Text = "Delete";
            this.bt_delete.UseVisualStyleBackColor = true;
            this.bt_delete.Click += new System.EventHandler(this.bt_delete_Click);
            // 
            // bt_add
            // 
            this.bt_add.Location = new System.Drawing.Point(690, 368);
            this.bt_add.Margin = new System.Windows.Forms.Padding(2);
            this.bt_add.Name = "bt_add";
            this.bt_add.Size = new System.Drawing.Size(93, 29);
            this.bt_add.TabIndex = 38;
            this.bt_add.Text = "Add";
            this.bt_add.UseVisualStyleBackColor = true;
            this.bt_add.Click += new System.EventHandler(this.bt_add_Click);
            // 
            // cb_type
            // 
            this.cb_type.FormattingEnabled = true;
            this.cb_type.Items.AddRange(new object[] {
            "GW",
            "GO",
            "GP",
            "CR",
            "CY",
            "PM"});
            this.cb_type.Location = new System.Drawing.Point(764, 321);
            this.cb_type.Margin = new System.Windows.Forms.Padding(2);
            this.cb_type.Name = "cb_type";
            this.cb_type.Size = new System.Drawing.Size(135, 24);
            this.cb_type.TabIndex = 37;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(671, 321);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(39, 16);
            this.label8.TabIndex = 36;
            this.label8.Text = "Type";
            // 
            // tb_minute
            // 
            this.tb_minute.Location = new System.Drawing.Point(764, 180);
            this.tb_minute.Margin = new System.Windows.Forms.Padding(2);
            this.tb_minute.Name = "tb_minute";
            this.tb_minute.Size = new System.Drawing.Size(135, 22);
            this.tb_minute.TabIndex = 35;
            // 
            // cb_team
            // 
            this.cb_team.FormattingEnabled = true;
            this.cb_team.Location = new System.Drawing.Point(764, 221);
            this.cb_team.Margin = new System.Windows.Forms.Padding(2);
            this.cb_team.Name = "cb_team";
            this.cb_team.Size = new System.Drawing.Size(135, 24);
            this.cb_team.TabIndex = 34;
            this.cb_team.SelectedIndexChanged += new System.EventHandler(this.cb_team_SelectedIndexChanged);
            // 
            // cb_player
            // 
            this.cb_player.FormattingEnabled = true;
            this.cb_player.Location = new System.Drawing.Point(764, 277);
            this.cb_player.Margin = new System.Windows.Forms.Padding(2);
            this.cb_player.Name = "cb_player";
            this.cb_player.Size = new System.Drawing.Size(135, 24);
            this.cb_player.TabIndex = 33;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(667, 277);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(46, 16);
            this.label7.TabIndex = 32;
            this.label7.Text = "Player";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(667, 229);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(43, 16);
            this.label6.TabIndex = 31;
            this.label6.Text = "Team";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(667, 180);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 16);
            this.label5.TabIndex = 30;
            this.label5.Text = "Minute";
            // 
            // dgv_1
            // 
            this.dgv_1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_1.Location = new System.Drawing.Point(43, 180);
            this.dgv_1.Margin = new System.Windows.Forms.Padding(2);
            this.dgv_1.Name = "dgv_1";
            this.dgv_1.RowHeadersWidth = 82;
            this.dgv_1.RowTemplate.Height = 33;
            this.dgv_1.Size = new System.Drawing.Size(562, 280);
            this.dgv_1.TabIndex = 29;
            this.dgv_1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_1_CellClick);
            // 
            // dtp_1
            // 
            this.dtp_1.Location = new System.Drawing.Point(756, 43);
            this.dtp_1.Margin = new System.Windows.Forms.Padding(2);
            this.dtp_1.Name = "dtp_1";
            this.dtp_1.Size = new System.Drawing.Size(135, 22);
            this.dtp_1.TabIndex = 28;
            this.dtp_1.ValueChanged += new System.EventHandler(this.dtp_1_ValueChanged);
            // 
            // cb_away
            // 
            this.cb_away.FormattingEnabled = true;
            this.cb_away.Location = new System.Drawing.Point(764, 110);
            this.cb_away.Margin = new System.Windows.Forms.Padding(2);
            this.cb_away.Name = "cb_away";
            this.cb_away.Size = new System.Drawing.Size(135, 24);
            this.cb_away.TabIndex = 27;
            this.cb_away.SelectedIndexChanged += new System.EventHandler(this.cb_away_SelectedIndexChanged);
            // 
            // cb_home
            // 
            this.cb_home.FormattingEnabled = true;
            this.cb_home.Location = new System.Drawing.Point(152, 118);
            this.cb_home.Margin = new System.Windows.Forms.Padding(2);
            this.cb_home.Name = "cb_home";
            this.cb_home.Size = new System.Drawing.Size(142, 24);
            this.cb_home.TabIndex = 26;
            this.cb_home.SelectedIndexChanged += new System.EventHandler(this.cb_home_SelectedIndexChanged);
            // 
            // tb_matchid
            // 
            this.tb_matchid.Location = new System.Drawing.Point(152, 45);
            this.tb_matchid.Margin = new System.Windows.Forms.Padding(2);
            this.tb_matchid.Name = "tb_matchid";
            this.tb_matchid.Size = new System.Drawing.Size(142, 22);
            this.tb_matchid.TabIndex = 25;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(667, 113);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 16);
            this.label4.TabIndex = 24;
            this.label4.Text = "Team Away";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(667, 45);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 16);
            this.label3.TabIndex = 23;
            this.label3.Text = "Match Date";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(57, 118);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 16);
            this.label2.TabIndex = 22;
            this.label2.Text = "Team Home";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(57, 45);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 16);
            this.label1.TabIndex = 21;
            this.label1.Text = "Match ID";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1051, 613);
            this.Controls.Add(this.bt_insert);
            this.Controls.Add(this.bt_delete);
            this.Controls.Add(this.bt_add);
            this.Controls.Add(this.cb_type);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.tb_minute);
            this.Controls.Add(this.cb_team);
            this.Controls.Add(this.cb_player);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.dgv_1);
            this.Controls.Add(this.dtp_1);
            this.Controls.Add(this.cb_away);
            this.Controls.Add(this.cb_home);
            this.Controls.Add(this.tb_matchid);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bt_insert;
        private System.Windows.Forms.Button bt_delete;
        private System.Windows.Forms.Button bt_add;
        private System.Windows.Forms.ComboBox cb_type;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tb_minute;
        private System.Windows.Forms.ComboBox cb_team;
        private System.Windows.Forms.ComboBox cb_player;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridView dgv_1;
        private System.Windows.Forms.DateTimePicker dtp_1;
        private System.Windows.Forms.ComboBox cb_away;
        private System.Windows.Forms.ComboBox cb_home;
        private System.Windows.Forms.TextBox tb_matchid;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}

