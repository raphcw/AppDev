﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static TH04_Raphael_Christiano.Form1;

namespace TH04_Raphael_Christiano
{
    public partial class Form1 : Form
    {
        List<Teams> teams = new List<Teams> ();
        List<Player> player = new List<Player> ();
        string teamyangdipilih = " ";
        public Form1()
        {
            InitializeComponent();
            cb_playerposition.Items.Add("GK");
            cb_playerposition.Items.Add("MF");
            cb_playerposition.Items.Add("FW");
            cb_playerposition.Items.Add("DF");
        }

        
        private void Form1_Load(object sender, EventArgs e)
        {
            teams = new List<Teams>();

            Teams team = new Teams("Manchester United", "England", "Manchester");
            team.AddPlayers("Keenan", "13", "FW");
            team.AddPlayers("Kevin", "99", "DF");
            team.AddPlayers("Edo", "71", "CF");
            team.AddPlayers("Valent", "34", "GK");
            team.AddPlayers("Steve", "88", "DF");
            team.AddPlayers("Jevon", "73", "MF");
            team.AddPlayers("Feli", "12", "MF");
            team.AddPlayers("Raph", "07", "FW");
            team.AddPlayers("Stanley", "10", "DF");
            team.AddPlayers("Shawn", "69", "GK");
            team.AddPlayers("Ruben", "77", "MF");
            teams.Add(team);

            team = new Teams("Chelsea", "England", "Fulham");
            team.AddPlayers("Amanda", "13", "FW");
            team.AddPlayers("Michelle", "99", "DF");
            team.AddPlayers("Feylin", "71", "CF");
            team.AddPlayers("Caca", "34", "GK");
            team.AddPlayers("Sherin", "88", "DF");
            team.AddPlayers("Ruby", "73", "MF");
            team.AddPlayers("Felix", "12", "MF");
            team.AddPlayers("Sean", "07", "FW");
            team.AddPlayers("Jessica", "10", "DF");
            team.AddPlayers("Natalie", "69", "GK");
            team.AddPlayers("Rayna", "77", "MF");
            teams.Add(team);

            team = new Teams("Bayern Munich", "Germany", "Munich");
            team.AddPlayers("Angela", "13", "FW");
            team.AddPlayers("Sharon", "99", "DF");
            team.AddPlayers("Arkan", "71", "CF");
            team.AddPlayers("Jefferson", "34", "GK");
            team.AddPlayers("Kwandy", "88", "DF");
            team.AddPlayers("Chris", "73", "MF");
            team.AddPlayers("Nathan", "12", "MF");
            team.AddPlayers("Noel", "07", "FW");
            team.AddPlayers("Collin", "10", "DF");
            team.AddPlayers("Dave", "69", "GK");
            team.AddPlayers("Ivan", "77", "MF");
            teams.Add(team);

            InitialCountry();
        }
        private void InitialCountry()
        {
            foreach (Teams team in teams)
            {
                if (!cb_country.Items.Contains(team.teamcountry))
                {
                    cb_country.Items.Add(team.teamcountry);
                }
            }
        }

        private void cb_country_SelectedIndexChanged(object sender, EventArgs e)
        {
            cb_team.Items.Clear();

            foreach (Teams team in teams)
            {
                if (team.teamcountry == cb_country.SelectedItem.ToString())
                {
                    cb_team.Items.Add(team.teamname);
                }
            }
        }

        private void cb_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            lbox_players.Items.Clear();

            foreach (Teams team in teams)
            {
                if (team.teamname == cb_team.SelectedItem.ToString())
                {
                    foreach (Player player in team.players)
                    {
                        lbox_players.Items.Add($"({player.playerNumber}) {player.playerName}, {player.playerPosition}");

                    }
                }
            }
        }

        public class Teams
        {
            public string teamname;
            public string teamcountry;
            public string teamcity;
            public List<Player> players;
            public Teams(string TeamName, string TeamCountry, string TeamCity)
            {
                teamname = TeamName;
                teamcountry = TeamCountry;
                teamcity = TeamCity;
                players = new List<Player>();
            }
            public void AddPlayers(string PlayerName, string PlayerNumber, string PlayerPosition)
            {
                players.Add(new Player(PlayerName, PlayerNumber, PlayerPosition));
            }
        }
        public class Player
        {
            public string playerName;
            public string playerNumber;
            public string playerPosition;

            public Player (string PlayerName, string PlayerNumber, string PlayerPosition)
            {
                playerName = PlayerName;
                playerNumber = PlayerNumber;
                playerPosition = PlayerPosition;
            }
        }

        private void btn_addteam_Click(object sender, EventArgs e)
        {
            if (tbox_teamName.Text != "" && tbox_teamCountry.Text != "" && tbox_teamCity.Text != "")
            {
                bool have = false;

                foreach (Teams team in teams)
                {
                    if (team.teamcountry == tbox_teamCountry.Text && team.teamname == tbox_teamName.Text)
                    {
                        have = true;
                        break;
                    }
                }

                if (have)
                {
                    MessageBox.Show("Team with the same name already exists.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                else
                {
                    Teams team = new Teams(tbox_teamName.Text, tbox_teamCountry.Text, tbox_teamCity.Text);
                    teams.Add(team);

                    if (cb_country.Items.Contains(team.teamcountry))
                    {
                        
                    }
                    else
                    {
                        cb_country.Items.Add(team.teamcountry);
                    }

                    if (cb_country.SelectedItem != null && cb_country.SelectedItem.ToString() == team.teamcountry)
                        {
                        cb_team.Items.Add(team.teamname);
                    }
                    tbox_teamName.Text = "";
                    tbox_teamCountry.Text = "";
                    tbox_teamCity.Text = "";

                }
                

            }
            else
            {
                MessageBox.Show("Team already exists.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }
        

        private void btn_addplayer_Click(object sender, EventArgs e)
        {
            if (cb_team.SelectedItem != null)
            {
                if (tbox_playerName.Text != "" && tbox_playerNumber.Text != "" && cb_playerposition.SelectedItem != null)
                {
                    foreach (string item in lbox_players.Items)
                    {
                        string[] parts = item.ToString().Split(new[] { ' ', ')' }, StringSplitOptions.RemoveEmptyEntries);
                        string playerNameInListBox = parts[1];
                        string playerNumberInListBox = parts[0].Substring(1);

                        if (playerNameInListBox == tbox_playerName.Text)
                        {
                            MessageBox.Show("Player with the same name already exists.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }

                        if (playerNumberInListBox == tbox_playerNumber.Text || playerNameInListBox == tbox_playerName.Text)
                        {
                            MessageBox.Show("Player with the same number already exists.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }

                    foreach (Teams team in teams)
                    {
                        if (team.teamname == cb_team.SelectedItem.ToString())
                        {
                            team.AddPlayers(tbox_playerName.Text, tbox_playerNumber.Text, cb_playerposition.SelectedItem.ToString());
                            RefreshPlayersList(team);
                            ClearPlayerInput();
                            return;
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please provide player details.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Please select a team first.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void RefreshPlayersList(Teams team)
        {
            lbox_players.Items.Clear();
            foreach (Player player in team.players)
            {
                lbox_players.Items.Add($"({player.playerNumber}) {player.playerName}, {player.playerPosition}");
            }
        }

        private void ClearPlayerInput()
        {
            tbox_playerName.Text = "";
            tbox_playerNumber.Text = "";
            cb_playerposition.SelectedIndex = -1; 
        }
    

        private void btn_remove_Click(object sender, EventArgs e)
        {
            if (lbox_players.Items.Count <= 11)
            {
                DialogResult dr = MessageBox.Show("Unable to remove if players is less than equal 11", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                lbox_players.Items.RemoveAt(lbox_players.SelectedIndex);
            }
        }
    }
}
