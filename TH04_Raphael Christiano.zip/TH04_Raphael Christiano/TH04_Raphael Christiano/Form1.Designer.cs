﻿namespace TH04_Raphael_Christiano
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_teamlist = new System.Windows.Forms.Label();
            this.lb_choosecountry = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lb_addteam = new System.Windows.Forms.Label();
            this.lb_teamname = new System.Windows.Forms.Label();
            this.lb_teamcountry = new System.Windows.Forms.Label();
            this.lb_addplayers = new System.Windows.Forms.Label();
            this.lb_playername = new System.Windows.Forms.Label();
            this.lb_playernumber = new System.Windows.Forms.Label();
            this.lb_teamcity = new System.Windows.Forms.Label();
            this.lb_playerposition = new System.Windows.Forms.Label();
            this.lbox_players = new System.Windows.Forms.ListBox();
            this.cb_country = new System.Windows.Forms.ComboBox();
            this.cb_team = new System.Windows.Forms.ComboBox();
            this.cb_playerposition = new System.Windows.Forms.ComboBox();
            this.tbox_teamName = new System.Windows.Forms.TextBox();
            this.tbox_teamCountry = new System.Windows.Forms.TextBox();
            this.tbox_teamCity = new System.Windows.Forms.TextBox();
            this.tbox_playerName = new System.Windows.Forms.TextBox();
            this.tbox_playerNumber = new System.Windows.Forms.TextBox();
            this.btn_addteam = new System.Windows.Forms.Button();
            this.btn_addplayer = new System.Windows.Forms.Button();
            this.btn_remove = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lb_teamlist
            // 
            this.lb_teamlist.AutoSize = true;
            this.lb_teamlist.Location = new System.Drawing.Point(47, 56);
            this.lb_teamlist.Name = "lb_teamlist";
            this.lb_teamlist.Size = new System.Drawing.Size(112, 16);
            this.lb_teamlist.TabIndex = 0;
            this.lb_teamlist.Text = "Soccer Team List";
            // 
            // lb_choosecountry
            // 
            this.lb_choosecountry.AutoSize = true;
            this.lb_choosecountry.Location = new System.Drawing.Point(5, 105);
            this.lb_choosecountry.Name = "lb_choosecountry";
            this.lb_choosecountry.Size = new System.Drawing.Size(102, 16);
            this.lb_choosecountry.TabIndex = 1;
            this.lb_choosecountry.Text = "Choose Country";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(5, 172);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Choose Team";
            // 
            // lb_addteam
            // 
            this.lb_addteam.AutoSize = true;
            this.lb_addteam.Location = new System.Drawing.Point(410, 56);
            this.lb_addteam.Name = "lb_addteam";
            this.lb_addteam.Size = new System.Drawing.Size(89, 16);
            this.lb_addteam.TabIndex = 3;
            this.lb_addteam.Text = "Adding Team";
            // 
            // lb_teamname
            // 
            this.lb_teamname.AutoSize = true;
            this.lb_teamname.Location = new System.Drawing.Point(338, 110);
            this.lb_teamname.Name = "lb_teamname";
            this.lb_teamname.Size = new System.Drawing.Size(83, 16);
            this.lb_teamname.TabIndex = 4;
            this.lb_teamname.Text = "Team Name";
            // 
            // lb_teamcountry
            // 
            this.lb_teamcountry.AutoSize = true;
            this.lb_teamcountry.Location = new System.Drawing.Point(338, 156);
            this.lb_teamcountry.Name = "lb_teamcountry";
            this.lb_teamcountry.Size = new System.Drawing.Size(91, 16);
            this.lb_teamcountry.TabIndex = 5;
            this.lb_teamcountry.Text = "Team Country";
            // 
            // lb_addplayers
            // 
            this.lb_addplayers.AutoSize = true;
            this.lb_addplayers.Location = new System.Drawing.Point(665, 56);
            this.lb_addplayers.Name = "lb_addplayers";
            this.lb_addplayers.Size = new System.Drawing.Size(99, 16);
            this.lb_addplayers.TabIndex = 6;
            this.lb_addplayers.Text = "Adding Players";
            // 
            // lb_playername
            // 
            this.lb_playername.AutoSize = true;
            this.lb_playername.Location = new System.Drawing.Point(565, 110);
            this.lb_playername.Name = "lb_playername";
            this.lb_playername.Size = new System.Drawing.Size(86, 16);
            this.lb_playername.TabIndex = 7;
            this.lb_playername.Text = "Player Name";
            // 
            // lb_playernumber
            // 
            this.lb_playernumber.AutoSize = true;
            this.lb_playernumber.Location = new System.Drawing.Point(565, 159);
            this.lb_playernumber.Name = "lb_playernumber";
            this.lb_playernumber.Size = new System.Drawing.Size(97, 16);
            this.lb_playernumber.TabIndex = 8;
            this.lb_playernumber.Text = "Player Number";
            // 
            // lb_teamcity
            // 
            this.lb_teamcity.AutoSize = true;
            this.lb_teamcity.Location = new System.Drawing.Point(338, 217);
            this.lb_teamcity.Name = "lb_teamcity";
            this.lb_teamcity.Size = new System.Drawing.Size(68, 16);
            this.lb_teamcity.TabIndex = 9;
            this.lb_teamcity.Text = "Team City";
            // 
            // lb_playerposition
            // 
            this.lb_playerposition.AutoSize = true;
            this.lb_playerposition.Location = new System.Drawing.Point(565, 217);
            this.lb_playerposition.Name = "lb_playerposition";
            this.lb_playerposition.Size = new System.Drawing.Size(97, 16);
            this.lb_playerposition.TabIndex = 10;
            this.lb_playerposition.Text = "Player Position";
            // 
            // lbox_players
            // 
            this.lbox_players.FormattingEnabled = true;
            this.lbox_players.ItemHeight = 16;
            this.lbox_players.Location = new System.Drawing.Point(8, 209);
            this.lbox_players.Name = "lbox_players";
            this.lbox_players.Size = new System.Drawing.Size(246, 196);
            this.lbox_players.TabIndex = 11;
            // 
            // cb_country
            // 
            this.cb_country.FormattingEnabled = true;
            this.cb_country.Location = new System.Drawing.Point(121, 102);
            this.cb_country.Name = "cb_country";
            this.cb_country.Size = new System.Drawing.Size(121, 24);
            this.cb_country.TabIndex = 12;
            this.cb_country.SelectedIndexChanged += new System.EventHandler(this.cb_country_SelectedIndexChanged);
            // 
            // cb_team
            // 
            this.cb_team.FormattingEnabled = true;
            this.cb_team.Location = new System.Drawing.Point(121, 169);
            this.cb_team.Name = "cb_team";
            this.cb_team.Size = new System.Drawing.Size(121, 24);
            this.cb_team.TabIndex = 13;
            this.cb_team.SelectedIndexChanged += new System.EventHandler(this.cb_team_SelectedIndexChanged);
            // 
            // cb_playerposition
            // 
            this.cb_playerposition.FormattingEnabled = true;
            this.cb_playerposition.Location = new System.Drawing.Point(668, 209);
            this.cb_playerposition.Name = "cb_playerposition";
            this.cb_playerposition.Size = new System.Drawing.Size(121, 24);
            this.cb_playerposition.TabIndex = 14;
            // 
            // tbox_teamName
            // 
            this.tbox_teamName.Location = new System.Drawing.Point(451, 104);
            this.tbox_teamName.Name = "tbox_teamName";
            this.tbox_teamName.Size = new System.Drawing.Size(100, 22);
            this.tbox_teamName.TabIndex = 15;
            // 
            // tbox_teamCountry
            // 
            this.tbox_teamCountry.Location = new System.Drawing.Point(451, 161);
            this.tbox_teamCountry.Name = "tbox_teamCountry";
            this.tbox_teamCountry.Size = new System.Drawing.Size(100, 22);
            this.tbox_teamCountry.TabIndex = 16;
            // 
            // tbox_teamCity
            // 
            this.tbox_teamCity.Location = new System.Drawing.Point(451, 217);
            this.tbox_teamCity.Name = "tbox_teamCity";
            this.tbox_teamCity.Size = new System.Drawing.Size(100, 22);
            this.tbox_teamCity.TabIndex = 17;
            // 
            // tbox_playerName
            // 
            this.tbox_playerName.Location = new System.Drawing.Point(668, 110);
            this.tbox_playerName.Name = "tbox_playerName";
            this.tbox_playerName.Size = new System.Drawing.Size(100, 22);
            this.tbox_playerName.TabIndex = 18;
            // 
            // tbox_playerNumber
            // 
            this.tbox_playerNumber.Location = new System.Drawing.Point(668, 156);
            this.tbox_playerNumber.Name = "tbox_playerNumber";
            this.tbox_playerNumber.Size = new System.Drawing.Size(100, 22);
            this.tbox_playerNumber.TabIndex = 19;
            // 
            // btn_addteam
            // 
            this.btn_addteam.Location = new System.Drawing.Point(413, 267);
            this.btn_addteam.Name = "btn_addteam";
            this.btn_addteam.Size = new System.Drawing.Size(75, 23);
            this.btn_addteam.TabIndex = 20;
            this.btn_addteam.Text = "Add";
            this.btn_addteam.UseVisualStyleBackColor = true;
            this.btn_addteam.Click += new System.EventHandler(this.btn_addteam_Click);
            // 
            // btn_addplayer
            // 
            this.btn_addplayer.Location = new System.Drawing.Point(689, 267);
            this.btn_addplayer.Name = "btn_addplayer";
            this.btn_addplayer.Size = new System.Drawing.Size(75, 23);
            this.btn_addplayer.TabIndex = 21;
            this.btn_addplayer.Text = "Add";
            this.btn_addplayer.UseVisualStyleBackColor = true;
            this.btn_addplayer.Click += new System.EventHandler(this.btn_addplayer_Click);
            // 
            // btn_remove
            // 
            this.btn_remove.Location = new System.Drawing.Point(12, 415);
            this.btn_remove.Name = "btn_remove";
            this.btn_remove.Size = new System.Drawing.Size(75, 23);
            this.btn_remove.TabIndex = 22;
            this.btn_remove.Text = "Remove";
            this.btn_remove.UseVisualStyleBackColor = true;
            this.btn_remove.Click += new System.EventHandler(this.btn_remove_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_remove);
            this.Controls.Add(this.btn_addplayer);
            this.Controls.Add(this.btn_addteam);
            this.Controls.Add(this.tbox_playerNumber);
            this.Controls.Add(this.tbox_playerName);
            this.Controls.Add(this.tbox_teamCity);
            this.Controls.Add(this.tbox_teamCountry);
            this.Controls.Add(this.tbox_teamName);
            this.Controls.Add(this.cb_playerposition);
            this.Controls.Add(this.cb_team);
            this.Controls.Add(this.cb_country);
            this.Controls.Add(this.lbox_players);
            this.Controls.Add(this.lb_playerposition);
            this.Controls.Add(this.lb_teamcity);
            this.Controls.Add(this.lb_playernumber);
            this.Controls.Add(this.lb_playername);
            this.Controls.Add(this.lb_addplayers);
            this.Controls.Add(this.lb_teamcountry);
            this.Controls.Add(this.lb_teamname);
            this.Controls.Add(this.lb_addteam);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lb_choosecountry);
            this.Controls.Add(this.lb_teamlist);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_teamlist;
        private System.Windows.Forms.Label lb_choosecountry;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lb_addteam;
        private System.Windows.Forms.Label lb_teamname;
        private System.Windows.Forms.Label lb_teamcountry;
        private System.Windows.Forms.Label lb_addplayers;
        private System.Windows.Forms.Label lb_playername;
        private System.Windows.Forms.Label lb_playernumber;
        private System.Windows.Forms.Label lb_teamcity;
        private System.Windows.Forms.Label lb_playerposition;
        private System.Windows.Forms.ListBox lbox_players;
        private System.Windows.Forms.ComboBox cb_country;
        private System.Windows.Forms.ComboBox cb_team;
        private System.Windows.Forms.ComboBox cb_playerposition;
        private System.Windows.Forms.TextBox tbox_teamName;
        private System.Windows.Forms.TextBox tbox_teamCountry;
        private System.Windows.Forms.TextBox tbox_teamCity;
        private System.Windows.Forms.TextBox tbox_playerName;
        private System.Windows.Forms.TextBox tbox_playerNumber;
        private System.Windows.Forms.Button btn_addteam;
        private System.Windows.Forms.Button btn_addplayer;
        private System.Windows.Forms.Button btn_remove;
    }
}

