﻿namespace TH05_Raphael_Christiano_Wahono
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.lb_product = new System.Windows.Forms.Label();
            this.lb_category = new System.Windows.Forms.Label();
            this.lb_details = new System.Windows.Forms.Label();
            this.lb_nama = new System.Windows.Forms.Label();
            this.lb_cat = new System.Windows.Forms.Label();
            this.lb_harga = new System.Windows.Forms.Label();
            this.lb_stock = new System.Windows.Forms.Label();
            this.dgv_1 = new System.Windows.Forms.DataGridView();
            this.dgv_2 = new System.Windows.Forms.DataGridView();
            this.btn_all = new System.Windows.Forms.Button();
            this.btn_filter = new System.Windows.Forms.Button();
            this.cb_filter = new System.Windows.Forms.ComboBox();
            this.tbox_nama = new System.Windows.Forms.TextBox();
            this.tbox_harga = new System.Windows.Forms.TextBox();
            this.tbox_stock = new System.Windows.Forms.TextBox();
            this.cb_category = new System.Windows.Forms.ComboBox();
            this.btn_addproduct = new System.Windows.Forms.Button();
            this.btn_editproduct = new System.Windows.Forms.Button();
            this.btn_removeproduct = new System.Windows.Forms.Button();
            this.lb_namaa = new System.Windows.Forms.Label();
            this.tbox_namacat = new System.Windows.Forms.TextBox();
            this.btn_addcategory = new System.Windows.Forms.Button();
            this.btn_removecategory = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_product
            // 
            this.lb_product.AutoSize = true;
            this.lb_product.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_product.Location = new System.Drawing.Point(25, 11);
            this.lb_product.Name = "lb_product";
            this.lb_product.Size = new System.Drawing.Size(119, 32);
            this.lb_product.TabIndex = 0;
            this.lb_product.Text = "Product";
            // 
            // lb_category
            // 
            this.lb_category.AutoSize = true;
            this.lb_category.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_category.Location = new System.Drawing.Point(672, 9);
            this.lb_category.Name = "lb_category";
            this.lb_category.Size = new System.Drawing.Size(137, 32);
            this.lb_category.TabIndex = 1;
            this.lb_category.Text = "Category";
            // 
            // lb_details
            // 
            this.lb_details.AutoSize = true;
            this.lb_details.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_details.Location = new System.Drawing.Point(7, 372);
            this.lb_details.Name = "lb_details";
            this.lb_details.Size = new System.Drawing.Size(109, 32);
            this.lb_details.TabIndex = 2;
            this.lb_details.Text = "Details";
            // 
            // lb_nama
            // 
            this.lb_nama.AutoSize = true;
            this.lb_nama.Location = new System.Drawing.Point(20, 417);
            this.lb_nama.Name = "lb_nama";
            this.lb_nama.Size = new System.Drawing.Size(50, 16);
            this.lb_nama.TabIndex = 3;
            this.lb_nama.Text = "Nama :";
            // 
            // lb_cat
            // 
            this.lb_cat.AutoSize = true;
            this.lb_cat.Location = new System.Drawing.Point(2, 451);
            this.lb_cat.Name = "lb_cat";
            this.lb_cat.Size = new System.Drawing.Size(68, 16);
            this.lb_cat.TabIndex = 4;
            this.lb_cat.Text = "Category :";
            // 
            // lb_harga
            // 
            this.lb_harga.AutoSize = true;
            this.lb_harga.Location = new System.Drawing.Point(19, 485);
            this.lb_harga.Name = "lb_harga";
            this.lb_harga.Size = new System.Drawing.Size(51, 16);
            this.lb_harga.TabIndex = 5;
            this.lb_harga.Text = "Harga :";
            // 
            // lb_stock
            // 
            this.lb_stock.AutoSize = true;
            this.lb_stock.Location = new System.Drawing.Point(23, 517);
            this.lb_stock.Name = "lb_stock";
            this.lb_stock.Size = new System.Drawing.Size(47, 16);
            this.lb_stock.TabIndex = 6;
            this.lb_stock.Text = "Stock :";
            // 
            // dgv_1
            // 
            this.dgv_1.AllowUserToAddRows = false;
            this.dgv_1.AllowUserToDeleteRows = false;
            this.dgv_1.AllowUserToResizeColumns = false;
            this.dgv_1.AllowUserToResizeRows = false;
            this.dgv_1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgv_1.Location = new System.Drawing.Point(5, 51);
            this.dgv_1.Name = "dgv_1";
            this.dgv_1.ReadOnly = true;
            this.dgv_1.RowHeadersVisible = false;
            this.dgv_1.RowHeadersWidth = 51;
            this.dgv_1.RowTemplate.Height = 24;
            this.dgv_1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_1.Size = new System.Drawing.Size(624, 296);
            this.dgv_1.TabIndex = 7;
            this.dgv_1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_1_CellClick);
            this.dgv_1.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_1_CellEndEdit);
            // 
            // dgv_2
            // 
            this.dgv_2.AllowUserToAddRows = false;
            this.dgv_2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_2.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgv_2.Location = new System.Drawing.Point(676, 51);
            this.dgv_2.Name = "dgv_2";
            this.dgv_2.ReadOnly = true;
            this.dgv_2.RowHeadersVisible = false;
            this.dgv_2.RowHeadersWidth = 51;
            this.dgv_2.RowTemplate.Height = 24;
            this.dgv_2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_2.Size = new System.Drawing.Size(256, 255);
            this.dgv_2.TabIndex = 8;
            this.dgv_2.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_2_CellClick);
            // 
            // btn_all
            // 
            this.btn_all.Location = new System.Drawing.Point(393, 22);
            this.btn_all.Name = "btn_all";
            this.btn_all.Size = new System.Drawing.Size(42, 23);
            this.btn_all.TabIndex = 9;
            this.btn_all.Text = "All";
            this.btn_all.UseVisualStyleBackColor = true;
            this.btn_all.Click += new System.EventHandler(this.btn_all_Click);
            // 
            // btn_filter
            // 
            this.btn_filter.Location = new System.Drawing.Point(441, 22);
            this.btn_filter.Name = "btn_filter";
            this.btn_filter.Size = new System.Drawing.Size(50, 23);
            this.btn_filter.TabIndex = 10;
            this.btn_filter.Text = "Filter";
            this.btn_filter.UseVisualStyleBackColor = true;
            this.btn_filter.Click += new System.EventHandler(this.btn_filter_Click);
            // 
            // cb_filter
            // 
            this.cb_filter.Enabled = false;
            this.cb_filter.FormattingEnabled = true;
            this.cb_filter.Items.AddRange(new object[] {
            "Jas",
            "T-Shirt",
            "Rok",
            "Celana",
            "Cawat"});
            this.cb_filter.Location = new System.Drawing.Point(507, 21);
            this.cb_filter.Name = "cb_filter";
            this.cb_filter.Size = new System.Drawing.Size(121, 24);
            this.cb_filter.TabIndex = 11;
            this.cb_filter.SelectedIndexChanged += new System.EventHandler(this.cb_filter_SelectedIndexChanged);
            // 
            // tbox_nama
            // 
            this.tbox_nama.Location = new System.Drawing.Point(76, 411);
            this.tbox_nama.Name = "tbox_nama";
            this.tbox_nama.Size = new System.Drawing.Size(378, 22);
            this.tbox_nama.TabIndex = 12;
            // 
            // tbox_harga
            // 
            this.tbox_harga.Location = new System.Drawing.Point(76, 482);
            this.tbox_harga.Name = "tbox_harga";
            this.tbox_harga.Size = new System.Drawing.Size(100, 22);
            this.tbox_harga.TabIndex = 13;
            this.tbox_harga.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbox_harga_KeyPress);
            // 
            // tbox_stock
            // 
            this.tbox_stock.Location = new System.Drawing.Point(76, 517);
            this.tbox_stock.Name = "tbox_stock";
            this.tbox_stock.Size = new System.Drawing.Size(100, 22);
            this.tbox_stock.TabIndex = 14;
            this.tbox_stock.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbox_stock_KeyPress);
            // 
            // cb_category
            // 
            this.cb_category.FormattingEnabled = true;
            this.cb_category.Location = new System.Drawing.Point(76, 448);
            this.cb_category.Name = "cb_category";
            this.cb_category.Size = new System.Drawing.Size(121, 24);
            this.cb_category.TabIndex = 15;
            this.cb_category.SelectedIndexChanged += new System.EventHandler(this.cb_category_SelectedIndexChanged);
            // 
            // btn_addproduct
            // 
            this.btn_addproduct.BackColor = System.Drawing.Color.Lime;
            this.btn_addproduct.Location = new System.Drawing.Point(216, 482);
            this.btn_addproduct.Name = "btn_addproduct";
            this.btn_addproduct.Size = new System.Drawing.Size(70, 51);
            this.btn_addproduct.TabIndex = 16;
            this.btn_addproduct.Text = "Add Product";
            this.btn_addproduct.UseVisualStyleBackColor = false;
            this.btn_addproduct.Click += new System.EventHandler(this.btn_addproduct_Click);
            // 
            // btn_editproduct
            // 
            this.btn_editproduct.BackColor = System.Drawing.Color.Yellow;
            this.btn_editproduct.Location = new System.Drawing.Point(292, 482);
            this.btn_editproduct.Name = "btn_editproduct";
            this.btn_editproduct.Size = new System.Drawing.Size(76, 51);
            this.btn_editproduct.TabIndex = 17;
            this.btn_editproduct.Text = "Edit Product";
            this.btn_editproduct.UseVisualStyleBackColor = false;
            this.btn_editproduct.Click += new System.EventHandler(this.btn_editproduct_Click);
            // 
            // btn_removeproduct
            // 
            this.btn_removeproduct.BackColor = System.Drawing.Color.Red;
            this.btn_removeproduct.Location = new System.Drawing.Point(374, 482);
            this.btn_removeproduct.Name = "btn_removeproduct";
            this.btn_removeproduct.Size = new System.Drawing.Size(76, 51);
            this.btn_removeproduct.TabIndex = 18;
            this.btn_removeproduct.Text = "Remove Product";
            this.btn_removeproduct.UseVisualStyleBackColor = false;
            this.btn_removeproduct.Click += new System.EventHandler(this.btn_removeproduct_Click);
            // 
            // lb_namaa
            // 
            this.lb_namaa.AutoSize = true;
            this.lb_namaa.Location = new System.Drawing.Point(673, 315);
            this.lb_namaa.Name = "lb_namaa";
            this.lb_namaa.Size = new System.Drawing.Size(50, 16);
            this.lb_namaa.TabIndex = 19;
            this.lb_namaa.Text = "Nama :";
            // 
            // tbox_namacat
            // 
            this.tbox_namacat.Location = new System.Drawing.Point(729, 312);
            this.tbox_namacat.Name = "tbox_namacat";
            this.tbox_namacat.Size = new System.Drawing.Size(158, 22);
            this.tbox_namacat.TabIndex = 20;
            // 
            // btn_addcategory
            // 
            this.btn_addcategory.BackColor = System.Drawing.Color.Lime;
            this.btn_addcategory.Location = new System.Drawing.Point(729, 340);
            this.btn_addcategory.Name = "btn_addcategory";
            this.btn_addcategory.Size = new System.Drawing.Size(80, 65);
            this.btn_addcategory.TabIndex = 21;
            this.btn_addcategory.Text = "Add Category";
            this.btn_addcategory.UseVisualStyleBackColor = false;
            this.btn_addcategory.Click += new System.EventHandler(this.btn_addcategory_Click);
            // 
            // btn_removecategory
            // 
            this.btn_removecategory.BackColor = System.Drawing.Color.Red;
            this.btn_removecategory.Location = new System.Drawing.Point(815, 340);
            this.btn_removecategory.Name = "btn_removecategory";
            this.btn_removecategory.Size = new System.Drawing.Size(79, 65);
            this.btn_removecategory.TabIndex = 22;
            this.btn_removecategory.Text = "Remove Category";
            this.btn_removecategory.UseVisualStyleBackColor = false;
            this.btn_removecategory.Click += new System.EventHandler(this.btn_removecategory_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(613, 429);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(187, 170);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 23;
            this.pictureBox1.TabStop = false;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSalmon;
            this.ClientSize = new System.Drawing.Size(1059, 611);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btn_removecategory);
            this.Controls.Add(this.btn_addcategory);
            this.Controls.Add(this.tbox_namacat);
            this.Controls.Add(this.lb_namaa);
            this.Controls.Add(this.btn_removeproduct);
            this.Controls.Add(this.btn_editproduct);
            this.Controls.Add(this.btn_addproduct);
            this.Controls.Add(this.cb_category);
            this.Controls.Add(this.tbox_stock);
            this.Controls.Add(this.tbox_harga);
            this.Controls.Add(this.tbox_nama);
            this.Controls.Add(this.cb_filter);
            this.Controls.Add(this.btn_filter);
            this.Controls.Add(this.btn_all);
            this.Controls.Add(this.dgv_2);
            this.Controls.Add(this.dgv_1);
            this.Controls.Add(this.lb_stock);
            this.Controls.Add(this.lb_harga);
            this.Controls.Add(this.lb_cat);
            this.Controls.Add(this.lb_nama);
            this.Controls.Add(this.lb_details);
            this.Controls.Add(this.lb_category);
            this.Controls.Add(this.lb_product);
            this.Name = "Main";
            this.Text = "Main";
            this.Load += new System.EventHandler(this.Main_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_product;
        private System.Windows.Forms.Label lb_category;
        private System.Windows.Forms.Label lb_details;
        private System.Windows.Forms.Label lb_nama;
        private System.Windows.Forms.Label lb_cat;
        private System.Windows.Forms.Label lb_harga;
        private System.Windows.Forms.Label lb_stock;
        private System.Windows.Forms.DataGridView dgv_1;
        private System.Windows.Forms.DataGridView dgv_2;
        private System.Windows.Forms.Button btn_all;
        private System.Windows.Forms.Button btn_filter;
        private System.Windows.Forms.ComboBox cb_filter;
        private System.Windows.Forms.TextBox tbox_nama;
        private System.Windows.Forms.TextBox tbox_harga;
        private System.Windows.Forms.TextBox tbox_stock;
        private System.Windows.Forms.ComboBox cb_category;
        private System.Windows.Forms.Button btn_addproduct;
        private System.Windows.Forms.Button btn_editproduct;
        private System.Windows.Forms.Button btn_removeproduct;
        private System.Windows.Forms.Label lb_namaa;
        private System.Windows.Forms.TextBox tbox_namacat;
        private System.Windows.Forms.Button btn_addcategory;
        private System.Windows.Forms.Button btn_removecategory;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}