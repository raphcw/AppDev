﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH05_Raphael_Christiano_Wahono
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
            this.KeyDown += new KeyEventHandler(Login_KeyDown);
            this.KeyPreview = true;

        }
        private void Login_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                Main mainForm = new Main();
                mainForm.Show();
                this.Hide();
            }
        }
        private void btn_skip_Click(object sender, EventArgs e)
        {
            Main mainForm = new Main();
            mainForm.Show();
            this.Hide();
        }
    }
}
