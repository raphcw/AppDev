﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH05_Raphael_Christiano_Wahono
{
    public partial class Main : Form
    {
        DataTable dtProduct = new DataTable();
        DataTable dtCategory = new DataTable();
        DataTable dtProductTampil = new DataTable();
        string cekidkategori = "";

        public Main()
        {
            InitializeComponent();
            tbox_harga.KeyPress += tbox_harga_KeyPress;
            tbox_stock.KeyPress += tbox_stock_KeyPress;
        }

        private void Main_Load(object sender, EventArgs e)
        {
            cb_category.SelectedIndexChanged += cb_category_SelectedIndexChanged;

            dtProduct = new DataTable();
            dtProduct.Columns.Add("ID Product");
            dtProduct.Columns.Add("Nama Product");
            dtProduct.Columns.Add("Harga");
            dtProduct.Columns.Add("Stock");
            dtProduct.Columns.Add("ID Category");

            dtProduct.Rows.Add("J001", "Jas Hitam", "100000", "10", "C1");
            dtProduct.Rows.Add("T001", "T-Shirt Black Pink", "70000", "20", "C2");
            dtProduct.Rows.Add("J002", "T-Shirt Obsessive", "75000", "16", "C2");
            dtProduct.Rows.Add("R001", "Rok Mini", "82000", "26", "C3");
            dtProduct.Rows.Add("J002", "Jeans Biru", "90000", "5", "C4");
            dtProduct.Rows.Add("C001", "Celana Pendek Coklat", "60000", "11", "C4");
            dtProduct.Rows.Add("C002", "Cawat Blink-blink", "1000000", "1", "C5");
            dtProduct.Rows.Add("R002", "Rocca Shirt", "50000", "8", "C2");

            dtProductTampil.Columns.Add("ID Product");
            dtProductTampil.Columns.Add("Nama Product");
            dtProductTampil.Columns.Add("Harga");
            dtProductTampil.Columns.Add("Stock");
            dtProductTampil.Columns.Add("ID Category");

            dtCategory = new DataTable();
            dtCategory.Columns.Add("ID Category");
            dtCategory.Columns.Add("Nama Category");
            dtCategory.Rows.Add("C1", "Jas");
            dtCategory.Rows.Add("C2", "T-Shirt");
            dtCategory.Rows.Add("C3", "Rok");
            dtCategory.Rows.Add("C4", "Celana");
            dtCategory.Rows.Add("C5", "Cawat");

            dgv_1.DataSource = dtProduct;
            dgv_2.DataSource = dtCategory;

            dgv_1.ClearSelection();
            dgv_2.ClearSelection();

            //cb_filter.Enabled = false;
            //cb_filter.DataSource = dtCategory;
            //cb_filter.DisplayMember = "Nama Category";
            //cb_filter.ValueMember = "ID Category";

            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                cb_category.Items.Add(dtCategory.Rows[i][1].ToString());
            }
        }

        private void btn_filter_Click(object sender, EventArgs e)
        {
            cb_filter.Enabled = true;
        }

        private void cb_filter_SelectedIndexChanged(object sender, EventArgs e)
        {
            dgv_1.DataSource = dtProductTampil;
            dtProductTampil.Clear();
            
            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                if (cb_filter.Text == dtCategory.Rows[i][1].ToString())
                {
                    cekidkategori = dtCategory.Rows[i][0].ToString();
                }
            }

            for (int i = 0; i < dtProduct.Rows.Count; i++)
            {
                if (dtProduct.Rows[i][4].ToString().Contains(cekidkategori))
                {
                    dtProductTampil.Rows.Add(dtProduct.Rows[i][0].ToString(), dtProduct.Rows[i][1].ToString(), dtProduct.Rows[i][2].ToString(), dtProduct.Rows[i][3].ToString(), dtProduct.Rows[i][4].ToString());
                }
            }
        }

        private void btn_addproduct_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(tbox_nama.Text) || string.IsNullOrEmpty(tbox_harga.Text) || string.IsNullOrEmpty(tbox_stock.Text) || cb_category.SelectedItem == null)
            {
                MessageBox.Show("Semua inputan harus diisi dan kategori harus dipilih.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (cb_category.SelectedItem == null)
            {
                MessageBox.Show("Pilih kategori terlebih dahulu.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!int.TryParse(tbox_harga.Text, out _) || !int.TryParse(tbox_stock.Text, out _))
            {
                MessageBox.Show("Harga dan stock harus berupa angka.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string productName = tbox_nama.Text;
            string firstChar = productName.Substring(0, 1).ToUpper();
            int count = dtProduct.AsEnumerable().Count(row => row.Field<string>("ID Product").StartsWith(firstChar));
            string productId = $"{firstChar}{count + 1:D3}";

            string kodekategori = "";
            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                if (cb_category.Text == dtCategory.Rows[i][1].ToString())
                {
                    kodekategori = dtCategory.Rows[i][0].ToString();
                }
            }
            dtProduct.Rows.Add(productId, productName, tbox_harga.Text, tbox_stock.Text, kodekategori);

            dgv_1.DataSource = dtProduct;
        }
        private void dgv_1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgv_1.Rows[e.RowIndex];
                tbox_nama.Text = row.Cells["Nama Product"].Value.ToString();
                tbox_harga.Text = row.Cells["Harga"].Value.ToString();
                tbox_stock.Text = row.Cells["Stock"].Value.ToString();

                string namakategori = "";
                for (int i = 0; i < dtCategory.Rows.Count; i ++)
                {
                    if (row.Cells["ID Category"].Value.ToString() == dtCategory.Rows[i][0])
                    {
                        namakategori = dtCategory.Rows[i][1].ToString();
                    }
                }
                cb_category.Text = namakategori;
            }
        }

        private void btn_editproduct_Click(object sender, EventArgs e)
        {
            if (dgv_1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Pilih produk yang akan diubah.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (string.IsNullOrEmpty(tbox_nama.Text) || string.IsNullOrEmpty(tbox_harga.Text) || string.IsNullOrEmpty(tbox_stock.Text) || cb_category.SelectedItem == null)
            {
                MessageBox.Show("Semua inputan harus diisi.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!int.TryParse(tbox_harga.Text, out _) || !int.TryParse(tbox_stock.Text, out _))
            {
                MessageBox.Show("Harga dan stock harus berupa angka.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            DataGridViewRow selectedRow = dgv_1.SelectedRows[0];
            selectedRow.Cells["Nama Product"].Value = tbox_nama.Text;
            selectedRow.Cells["Harga"].Value = tbox_harga.Text;
            selectedRow.Cells["Stock"].Value = tbox_stock.Text;

            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                if (cb_category.Text == dtCategory.Rows[i][1].ToString())
                {
                    selectedRow.Cells["ID Category"].Value = dtCategory.Rows[i][0].ToString();
                }
            }

            tbox_nama.Clear();
            tbox_harga.Clear();
            tbox_stock.Clear();
            cb_category.Text = "";
        }

        private void btn_removeproduct_Click(object sender, EventArgs e)
        {
            if (dgv_1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Pilih produk yang akan dihapus.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (cb_filter.Text != "")
            {
                DataGridViewRow currentrow = dgv_1.CurrentRow;
                int indexcurrentrow = dgv_1.CurrentRow.Index;

                dgv_1.DataSource = dtProduct;

                for (int i = 0; i < dtProduct.Rows.Count; i++)
                {
                    if (dtProduct.Rows[i][0].ToString() == dtProductTampil.Rows[indexcurrentrow][0].ToString())
                    {
                        dtProduct.Rows.RemoveAt(i);
                    }
                }

                cb_filter.Text = "";
            }
            else
            {
                foreach (DataGridViewRow selectedRow in dgv_1.SelectedRows)
                {
                    dtProduct.Rows.RemoveAt(selectedRow.Index);
                }

                tbox_nama.Clear();
                tbox_harga.Clear();
                tbox_stock.Clear();
                cb_category.Text = "";
            }
        }

        private void btn_addcategory_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(tbox_namacat.Text))
            {
                MessageBox.Show("Nama kategori harus diisi.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string categoryName = tbox_namacat.Text;
            if (dtCategory.AsEnumerable().Any(row => row.Field<string>("Nama Category").Equals(categoryName, StringComparison.OrdinalIgnoreCase)))
            {
                MessageBox.Show("Kategori sudah ada.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //int largestId = dtCategory.AsEnumerable().Max(row => int.Parse(row.Field<string>("ID Category").Substring(1)));
            int largestId = 0;
            for (int i =0 ; i < dtCategory.Rows.Count; i++)
            {
                largestId = Convert.ToInt16(dtCategory.Rows[i][0].ToString().Substring(1));
            }
            largestId++;
            string categoryId = "C" + (largestId);

            DataRow newCategory = dtCategory.NewRow();
            newCategory["ID Category"] = categoryId;
            newCategory["Nama Category"] = categoryName;
            dtCategory.Rows.Add(newCategory);

            cb_filter.Items.Clear();
            cb_category.Items.Clear();
            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                cb_filter.Items.Add(dtCategory.Rows[i][1].ToString());
                cb_category.Items.Add(dtCategory.Rows[i][1].ToString());
            }
        }
        private void dgv_2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgv_2.Rows[e.RowIndex];
                tbox_namacat.Text = row.Cells["Nama Category"].Value.ToString();
            }
        }

        private void btn_removecategory_Click(object sender, EventArgs e)
        {
            cb_filter.Text = "";
            if (dgv_2.SelectedCells.Count == 0)
            {
                MessageBox.Show("Pilih kategori yang akan dihapus.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            DataGridViewRow selectedRow = dgv_2.SelectedCells[0].OwningRow;
            string categoryId = selectedRow.Cells["ID Category"].Value.ToString();
            DataRow[] productsToRemove = dtProduct.Select($"[ID Category] = '{categoryId}'");
            foreach (DataRow productRow in productsToRemove)
            {
                dtProduct.Rows.Remove(productRow);
            }
            dtCategory.Rows.RemoveAt(selectedRow.Index);

            dgv_1.DataSource = dtProduct;
            tbox_namacat.Clear();

            cb_filter.Items.Clear();
            cb_category.Items.Clear();
            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                cb_filter.Items.Add(dtCategory.Rows[i][1].ToString());
                cb_category.Items.Add(dtCategory.Rows[i][1].ToString());
            }
        }

        private void dgv_1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == dgv_1.Columns["Stock"].Index)
            {
                int newStock;
                if (int.TryParse(dgv_1.Rows[e.RowIndex].Cells["Stock"].Value.ToString(), out newStock))
                {
                    if (newStock == 0)
                    {
                        dtProduct.Rows.RemoveAt(e.RowIndex);
                    }
                }
                else
                {
                    MessageBox.Show("Stok harus berupa angka.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void cb_category_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedCategory = cb_category.SelectedItem.ToString();

            DataRow[] categoryRows = dtCategory.Select($"[ID Category] = '{selectedCategory}'");
            if (categoryRows.Length > 0)
            {
                dtProductTampil = dtProduct.AsEnumerable().Where(row => row.Field<string>("ID Category") == selectedCategory).CopyToDataTable();
                dgv_1.DataSource = dtProductTampil;
            }
        }

        private void btn_all_Click(object sender, EventArgs e)
        {
            cb_filter.Enabled = false;
            dgv_1.DataSource = dtProduct;
            cb_filter.Text = "";
           
        }

        private void tbox_harga_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbox_stock_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }

}
