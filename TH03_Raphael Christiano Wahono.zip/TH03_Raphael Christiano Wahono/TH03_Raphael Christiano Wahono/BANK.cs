﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH03_Raphael_Christiano_Wahono
{
    public partial class BANK : Form
    {
        List<string> username2 = new List<string>();
        List<string> password2 = new List<string>();
        List<int> balance2 = new List<int>();
        string nama;
        public BANK(List<string> username , List<string> password, List<int> balance, string tampung)
        {
            InitializeComponent();
            username2 = username;
            password2 = password;
            balance2 = balance;
            nama = tampung;
            ResetBalance();
        }

        private void ResetBalance()
        {
           
            for ( int i = 0; i < username2.Count; i++ )
            {
                if (username2[i] ==  nama)
                {
                    lb_balance.Text = "Rp. " + balance2[i].ToString("#,##0");
                }
            }
        }

        private void BANK_Load(object sender, EventArgs e)
        {

        }

        private void btn_logout_Click(object sender, EventArgs e)
        {
            bool ganti = true;
            Form1 form = new Form1(username2,password2,balance2, ganti);
            this.Hide();
            form.ShowDialog();
            
        }

        private void btn_deposit_Click(object sender, EventArgs e)
        {
            panel2.Visible = true;
            panel1.Visible = false;
        }

        private void btn_depositamount_Click(object sender, EventArgs e)
        {
            int tampungdeposit;
            if (!int.TryParse(tbox_depositamount.Text, out tampungdeposit) || tampungdeposit <= 0)
            {
                MessageBox.Show("Please enter a valid amount.");
                return;
            }

            for (int i = 0; i < username2.Count; i++ )
            {
                if (username2[i] == nama)
                {
                    balance2[i] += tampungdeposit;
                }
            }

            panel1.Visible = true;
            panel2.Visible = false;
            ResetBalance();
        }

        private void btn_withdraw_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
            panel3.Visible = true;
            for (int i = 0; i < username2.Count; i++)
            {
                if (username2[i] == nama)
                {
                    lb_rp.Text = "Rp. " + balance2[i].ToString("#,##0");
                }
            }
        }

        private void btn_withdrawamount_Click(object sender, EventArgs e)
        {
            int tampungdeposit;
            if (!int.TryParse(tbox_withdrawamount.Text, out tampungdeposit) || tampungdeposit <= 0)
            {
                MessageBox.Show("Please enter a valid amount.");
                return;
            }

            for (int i = 0; i < username2.Count; i++)
            {
                if (username2[i] == nama)
                {
                    if (balance2[i] < tampungdeposit)
                    {
                        MessageBox.Show("Error");
                        return;
                    } 

                    else
                    {
                        balance2[i] -= tampungdeposit;
                    }
                }
            }

            panel1.Visible = true;
            panel3.Visible = false;
            ResetBalance();
        }
    }
}
