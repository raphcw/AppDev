﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH03_Raphael_Christiano_Wahono
{
    public partial class Form1 : Form
    {
        List<string> username = new List<string>();
        List<string> password = new List<string>();
        List<int> balance = new List<int>();
        bool kembali = false;
        public Form1(List<string> usernames, List<string> someOtherList, List<int> someIntList, bool someBoolValue)
        {
            InitializeComponent();
            kembali = someBoolValue;

            if (kembali = true)
            {
                username = usernames;
                password = someOtherList;
                balance = someIntList;
            } 

            
        }

        private void btn_register_Click(object sender, EventArgs e)
        {
            panel2.Visible = true;
            panel1.Visible = false;
        }

        private void btn_register2_Click(object sender, EventArgs e)
        {
            string tempusername = textBox3.Text;
            string temppassword = textBox4.Text;

            if (username.Contains(tempusername))
            {
                MessageBox.Show("Nama sudah ada");
                return;
            }
            else
            {
                username.Add(tempusername);
                password.Add(temppassword);
                balance.Add(0);
                panel1.Visible = true;
                panel2.Visible = false;
                MessageBox.Show("Berhasil register");
            }
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            string tempusername = textBox1.Text;
            string temppassword = textBox2.Text;
            string salahusername = " ";
            bool salahpassword = false;
            for (int i = 0; i < username.Count; i++)
            {

                if (username[i] == tempusername)
                {
                    if (password[i] == temppassword)
                    {
                        string tampung = username[i];
                        BANK bank = new BANK(username, password, balance, tampung);
                        this.Hide();
                        bank.ShowDialog();
                        
                        return;
                    }
                    else
                    {
                        salahpassword = true;
                    }
                }
            }

            salahusername += "Username tidak ketemu\n";

            if (salahpassword = true)
            {
                salahusername += "Salah password";
            }
            MessageBox.Show(salahusername);

            
        }
    }
}
