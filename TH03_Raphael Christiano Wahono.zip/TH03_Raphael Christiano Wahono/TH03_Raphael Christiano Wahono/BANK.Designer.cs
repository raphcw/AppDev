﻿namespace TH03_Raphael_Christiano_Wahono
{
    partial class BANK
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_balancetext = new System.Windows.Forms.Label();
            this.lb_balance = new System.Windows.Forms.Label();
            this.btn_logout = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_deposit = new System.Windows.Forms.Button();
            this.btn_withdraw = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lb_depositamount = new System.Windows.Forms.Label();
            this.tbox_depositamount = new System.Windows.Forms.TextBox();
            this.btn_depositamount = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btn_withdrawamount = new System.Windows.Forms.Button();
            this.tbox_withdrawamount = new System.Windows.Forms.TextBox();
            this.lb_withdrawamount = new System.Windows.Forms.Label();
            this.lb_withdrawbalance = new System.Windows.Forms.Label();
            this.lb_rp = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // lb_balancetext
            // 
            this.lb_balancetext.AutoSize = true;
            this.lb_balancetext.Location = new System.Drawing.Point(3, 14);
            this.lb_balancetext.Name = "lb_balancetext";
            this.lb_balancetext.Size = new System.Drawing.Size(60, 16);
            this.lb_balancetext.TabIndex = 0;
            this.lb_balancetext.Text = "Balance:";
            // 
            // lb_balance
            // 
            this.lb_balance.AutoSize = true;
            this.lb_balance.Location = new System.Drawing.Point(71, 14);
            this.lb_balance.Name = "lb_balance";
            this.lb_balance.Size = new System.Drawing.Size(28, 16);
            this.lb_balance.TabIndex = 1;
            this.lb_balance.Text = "Rp.";
            // 
            // btn_logout
            // 
            this.btn_logout.Location = new System.Drawing.Point(677, 77);
            this.btn_logout.Name = "btn_logout";
            this.btn_logout.Size = new System.Drawing.Size(84, 33);
            this.btn_logout.TabIndex = 4;
            this.btn_logout.Text = "Logout";
            this.btn_logout.UseVisualStyleBackColor = true;
            this.btn_logout.Click += new System.EventHandler(this.btn_logout_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btn_withdraw);
            this.panel1.Controls.Add(this.btn_deposit);
            this.panel1.Controls.Add(this.lb_balancetext);
            this.panel1.Controls.Add(this.lb_balance);
            this.panel1.Location = new System.Drawing.Point(237, 202);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 194);
            this.panel1.TabIndex = 5;
            // 
            // btn_deposit
            // 
            this.btn_deposit.Location = new System.Drawing.Point(48, 56);
            this.btn_deposit.Name = "btn_deposit";
            this.btn_deposit.Size = new System.Drawing.Size(89, 43);
            this.btn_deposit.TabIndex = 2;
            this.btn_deposit.Text = "Deposit";
            this.btn_deposit.UseVisualStyleBackColor = true;
            this.btn_deposit.Click += new System.EventHandler(this.btn_deposit_Click);
            // 
            // btn_withdraw
            // 
            this.btn_withdraw.Location = new System.Drawing.Point(48, 113);
            this.btn_withdraw.Name = "btn_withdraw";
            this.btn_withdraw.Size = new System.Drawing.Size(89, 37);
            this.btn_withdraw.TabIndex = 6;
            this.btn_withdraw.Text = "Withdraw";
            this.btn_withdraw.UseVisualStyleBackColor = true;
            this.btn_withdraw.Click += new System.EventHandler(this.btn_withdraw_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btn_depositamount);
            this.panel2.Controls.Add(this.tbox_depositamount);
            this.panel2.Controls.Add(this.lb_depositamount);
            this.panel2.Location = new System.Drawing.Point(237, 202);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(200, 194);
            this.panel2.TabIndex = 6;
            this.panel2.Visible = false;
            // 
            // lb_depositamount
            // 
            this.lb_depositamount.AutoSize = true;
            this.lb_depositamount.Location = new System.Drawing.Point(30, 14);
            this.lb_depositamount.Name = "lb_depositamount";
            this.lb_depositamount.Size = new System.Drawing.Size(136, 16);
            this.lb_depositamount.TabIndex = 7;
            this.lb_depositamount.Text = "Input Deposit Amount:";
            // 
            // tbox_depositamount
            // 
            this.tbox_depositamount.Location = new System.Drawing.Point(50, 56);
            this.tbox_depositamount.Name = "tbox_depositamount";
            this.tbox_depositamount.Size = new System.Drawing.Size(100, 22);
            this.tbox_depositamount.TabIndex = 8;
            // 
            // btn_depositamount
            // 
            this.btn_depositamount.Location = new System.Drawing.Point(50, 100);
            this.btn_depositamount.Name = "btn_depositamount";
            this.btn_depositamount.Size = new System.Drawing.Size(100, 42);
            this.btn_depositamount.TabIndex = 9;
            this.btn_depositamount.Text = "Deposit";
            this.btn_depositamount.UseVisualStyleBackColor = true;
            this.btn_depositamount.Click += new System.EventHandler(this.btn_depositamount_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.lb_rp);
            this.panel3.Controls.Add(this.lb_withdrawbalance);
            this.panel3.Controls.Add(this.btn_withdrawamount);
            this.panel3.Controls.Add(this.tbox_withdrawamount);
            this.panel3.Controls.Add(this.lb_withdrawamount);
            this.panel3.Location = new System.Drawing.Point(237, 205);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(200, 194);
            this.panel3.TabIndex = 7;
            this.panel3.Visible = false;
            // 
            // btn_withdrawamount
            // 
            this.btn_withdrawamount.Location = new System.Drawing.Point(53, 153);
            this.btn_withdrawamount.Name = "btn_withdrawamount";
            this.btn_withdrawamount.Size = new System.Drawing.Size(94, 29);
            this.btn_withdrawamount.TabIndex = 9;
            this.btn_withdrawamount.Text = "Withdraw";
            this.btn_withdrawamount.UseVisualStyleBackColor = true;
            this.btn_withdrawamount.Click += new System.EventHandler(this.btn_withdrawamount_Click);
            // 
            // tbox_withdrawamount
            // 
            this.tbox_withdrawamount.Location = new System.Drawing.Point(53, 110);
            this.tbox_withdrawamount.Name = "tbox_withdrawamount";
            this.tbox_withdrawamount.Size = new System.Drawing.Size(100, 22);
            this.tbox_withdrawamount.TabIndex = 8;
            // 
            // lb_withdrawamount
            // 
            this.lb_withdrawamount.AutoSize = true;
            this.lb_withdrawamount.Location = new System.Drawing.Point(30, 14);
            this.lb_withdrawamount.Name = "lb_withdrawamount";
            this.lb_withdrawamount.Size = new System.Drawing.Size(144, 16);
            this.lb_withdrawamount.TabIndex = 7;
            this.lb_withdrawamount.Text = "Input Withdraw Amount:";
            // 
            // lb_withdrawbalance
            // 
            this.lb_withdrawbalance.AutoSize = true;
            this.lb_withdrawbalance.Location = new System.Drawing.Point(3, 42);
            this.lb_withdrawbalance.Name = "lb_withdrawbalance";
            this.lb_withdrawbalance.Size = new System.Drawing.Size(60, 16);
            this.lb_withdrawbalance.TabIndex = 10;
            this.lb_withdrawbalance.Text = "Balance:";
            // 
            // lb_rp
            // 
            this.lb_rp.AutoSize = true;
            this.lb_rp.Location = new System.Drawing.Point(80, 42);
            this.lb_rp.Name = "lb_rp";
            this.lb_rp.Size = new System.Drawing.Size(28, 16);
            this.lb_rp.TabIndex = 11;
            this.lb_rp.Text = "Rp.";
            // 
            // BANK
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btn_logout);
            this.Name = "BANK";
            this.Text = "BANK";
            this.Load += new System.EventHandler(this.BANK_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lb_balancetext;
        private System.Windows.Forms.Label lb_balance;
        private System.Windows.Forms.Button btn_logout;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_deposit;
        private System.Windows.Forms.Button btn_withdraw;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btn_depositamount;
        private System.Windows.Forms.TextBox tbox_depositamount;
        private System.Windows.Forms.Label lb_depositamount;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lb_withdrawbalance;
        private System.Windows.Forms.Button btn_withdrawamount;
        private System.Windows.Forms.TextBox tbox_withdrawamount;
        private System.Windows.Forms.Label lb_withdrawamount;
        private System.Windows.Forms.Label lb_rp;
    }
}