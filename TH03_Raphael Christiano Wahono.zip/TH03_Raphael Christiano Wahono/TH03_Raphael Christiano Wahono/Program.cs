﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH03_Raphael_Christiano_Wahono
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {

            // Create empty lists and set the boolean value to false
            List<string> usernames = new List<string>();
            List<string> someOtherList = new List<string>();
            List<int> someIntList = new List<int>();
            bool someBoolValue = false;
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1(usernames, someOtherList, someIntList, someBoolValue));
        }
    }
}
