﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH09_Raphael_Christiano_Wahono
{
    public partial class Form1 : Form
    {
        DataTable dt = new DataTable();
        int totalPrice;
        int tampunganTotal;
        int totals = 0;
        int index = 0;
        int baris;
        public Form1()
        {
            InitializeComponent();
        }
        
        private void Form1_Load(object sender, EventArgs e)
        {
            tb_subtotal.Enabled = false;
            tb_total.Enabled = false;
            dt.Columns.Add("Quantity");
            dt.Columns.Add("Item Name");
            dt.Columns.Add("Item Price");
            dt.Columns.Add("Total");
            dgv_clothing.DataSource = dt;
            p_jewel.Visible = false;
            p_shoes.Visible = false;
            p_pants.Visible = false;
            p_long.Visible = false;
            p_shirt.Visible = false;
            p_tshirt.Visible = false;

        }
        int counter = 0;

        private void bt_tshirt1_Click(object sender, EventArgs e)
        {
            int tax;
            bool exists = false;
            int price = 180000;
            foreach (DataGridViewRow row in dgv_clothing.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Black T-Shirt")
                {
                    exists = true;
                    int currentQuantity = Convert.ToInt32(row.Cells[0].Value); 
                    row.Cells[0].Value = currentQuantity + 1;

                    totals = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[3].Value = totals * price;
                    break;
                                                              
                }
            }
            if(exists == false)
            {
                dt.Rows.Add(1, "Black T-Shirt", "Rp 180.000", price);
            }
            tampunganTotal = totalPrice += price;
            tax = totalPrice / 10;
            tb_subtotal.Text = (tampunganTotal.ToString());
            tb_total.Text = (tampunganTotal + tax).ToString();
        }

        private void bt_tshirt2_Click(object sender, EventArgs e)
        {
            int tax;
            bool exists = false;
            int price = 150000;
            foreach (DataGridViewRow row in dgv_clothing.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "White T-Shirt")
                {
                    exists = true;
                    int currentQuantity = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[0].Value = currentQuantity + 1;

                    totals = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[3].Value = totals * price;
                    break;
                   
                }
            }
            if (exists == false)
            {
                dt.Rows.Add(1, "White T-Shirt", "Rp 150.000", price);
            }
            tampunganTotal = totalPrice += price;
            tax = totalPrice / 10;
            tb_subtotal.Text = (tampunganTotal.ToString());
            tb_total.Text = (tampunganTotal + tax).ToString();
        }

        private void bt_tshirt3_Click(object sender, EventArgs e)
        {
            int tax;
            bool exists = false;
            int price = 170000;
            foreach (DataGridViewRow row in dgv_clothing.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Green T-Shirt")
                {
                    exists = true;
                    int currentQuantity = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[0].Value = currentQuantity + 1;
                    
                    totals = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[3].Value = totals * price;
                    break;
                }
            }
            if (exists == false)
            {
                dt.Rows.Add(1, "Green T-Shirt", "Rp 170.000", price);
            }
            tampunganTotal = totalPrice += price;
            tax = totalPrice / 10;
            tb_subtotal.Text = (tampunganTotal.ToString());
            tb_total.Text = (tampunganTotal + tax).ToString();
        }

        private void bt_shirt1_Click(object sender, EventArgs e)
        {
            int tax;
            bool exists = false;
            int price = 280000;
            foreach (DataGridViewRow row in dgv_clothing.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Black Shirt")
                {
                    exists = true;
                    int currentQuantity = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[0].Value = currentQuantity + 1;

                    totals = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[3].Value = totals * price;
                    break;
                }
            }
            if (exists == false)
            {
                dt.Rows.Add(1, "Black Shirt", "Rp 280.000", price);
            }
            tampunganTotal = totalPrice += price;
            tax = totalPrice / 10;
            tb_subtotal.Text = (tampunganTotal.ToString());
            tb_total.Text = (tampunganTotal + tax).ToString();
        }

        private void bt_shirt2_Click(object sender, EventArgs e)
        {
            int tax;
            bool exists = false;
            int price = 650000;
            foreach (DataGridViewRow row in dgv_clothing.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Navy Shirt")
                {
                    exists = true;
                    int currentQuantity = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[0].Value = currentQuantity + 1;

                    totals = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[3].Value = totals * price;
                    break;
                }
            }
            if (exists == false)
            {
                dt.Rows.Add(1, "Navy Shirt", "Rp 650.000", price);
            }
            tampunganTotal = totalPrice += price;
            tax = totalPrice / 10;
            tb_subtotal.Text = (tampunganTotal.ToString());
            tb_total.Text = (tampunganTotal + tax).ToString();
        }

        private void bt_shirt3_Click(object sender, EventArgs e)
        {
            int tax;
            bool exists = false;
            int price = 475000;
            foreach (DataGridViewRow row in dgv_clothing.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Red Shirt")
                {
                    exists = true;
                    int currentQuantity = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[0].Value = currentQuantity + 1;

                    totals = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[3].Value = totals * price;
                    break;
                }
            }
            if (exists == false)
            {
                dt.Rows.Add(1, "Red Shirt", "Rp 475.000", price);
            }
            tampunganTotal = totalPrice += price;
            tax = totalPrice / 10;
            tb_subtotal.Text = (tampunganTotal.ToString());
            tb_total.Text = (tampunganTotal + tax).ToString();
        }

        private void bt_pants1_Click(object sender, EventArgs e)
        {
            int tax;
            bool exists = false;
            int price = 150000;
            foreach (DataGridViewRow row in dgv_clothing.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Black Pants")
                {
                    exists = true;
                    int currentQuantity = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[0].Value = currentQuantity + 1;

                    totals = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[3].Value = totals * price;
                    break;
                }
            }
            if (exists == false)
            {
                dt.Rows.Add(1, "Black Pants", "Rp 150.000", price);
            }
            tampunganTotal = totalPrice += price;
            tax = totalPrice / 10;
            tb_subtotal.Text = (tampunganTotal.ToString());
            tb_total.Text = (tampunganTotal + tax).ToString();
        }

        private void bt_pants2_Click(object sender, EventArgs e)
        {
            int tax;
            bool exists = false;
            int price = 150000;
            foreach (DataGridViewRow row in dgv_clothing.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "White Pants")
                {
                    exists = true;
                    int currentQuantity = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[0].Value = currentQuantity + 1;

                    totals = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[3].Value = totals * price;
                    break;
                }
            }
            if (exists == false)
            {
                dt.Rows.Add(1, "White Pants", "Rp 150.000", price);
            }
            tampunganTotal = totalPrice += price;
            tax = totalPrice / 10;
            tb_subtotal.Text = (tampunganTotal.ToString());
            tb_total.Text = (tampunganTotal + tax).ToString();
        }

        private void bt_pants3_Click(object sender, EventArgs e)
        {
            int tax;
            bool exists = false;
            int price = 150000;
            foreach (DataGridViewRow row in dgv_clothing.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Sage Pants")
                {
                    exists = true;
                    int currentQuantity = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[0].Value = currentQuantity + 1;

                    totals = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[3].Value = totals * price;
                    break;
                }
            }
            if (exists == false)
            {
                dt.Rows.Add(1, "Sage Pants", "Rp 150.000", price);
            }
            tampunganTotal = totalPrice += price;
            tax = totalPrice / 10;
            tb_subtotal.Text = (tampunganTotal.ToString());
            tb_total.Text = (tampunganTotal + tax).ToString();
        }

        private void bt_long1_Click(object sender, EventArgs e)
        {
            int tax;
            bool exists = false;
            int price = 180000;
            foreach (DataGridViewRow row in dgv_clothing.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Black Cargo Pants")
                {
                    exists = true;
                    int currentQuantity = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[0].Value = currentQuantity + 1;

                    totals = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[3].Value = totals * price;
                    break;
                }
            }
            if (exists == false)
            {
                dt.Rows.Add(1, "Black Cargo Pants", "Rp 180.000", price);
            }
            tampunganTotal = totalPrice += price;
            tax = totalPrice / 10;
            tb_subtotal.Text = (tampunganTotal.ToString());
            tb_total.Text = (tampunganTotal + tax).ToString();
        }

        private void bt_long2_Click(object sender, EventArgs e)
        {
            int tax;
            bool exists = false;
            int price = 240000;
            foreach (DataGridViewRow row in dgv_clothing.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Khaki Sweatpants")
                {
                    exists = true;
                    int currentQuantity = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[0].Value = currentQuantity + 1;

                    totals = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[3].Value = totals * price;
                    break;
                }
            }
            if (exists == false)
            {
                dt.Rows.Add(1, "Khaki Sweatpants", "Rp 240.000", price);
            }
            tampunganTotal = totalPrice += price;
            tax = totalPrice / 10;
            tb_subtotal.Text = (tampunganTotal.ToString());
            tb_total.Text = (tampunganTotal + tax).ToString();
        }

        private void bt_long3_Click(object sender, EventArgs e)
        {
            int tax;
            bool exists = false;
            int price = 575000;
            foreach (DataGridViewRow row in dgv_clothing.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Grey Formal Pants")
                {
                    exists = true;
                    int currentQuantity = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[0].Value = currentQuantity + 1;

                    totals = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[3].Value = totals * price;
                    break;
                }
            }
            if (exists == false)
            {
                dt.Rows.Add(1, "Grey Formal Pants", "Rp 575.000", price);
            }
            tampunganTotal = totalPrice += price;
            tax = totalPrice / 10;
            tb_subtotal.Text = (tampunganTotal.ToString());
            tb_total.Text = (tampunganTotal + tax).ToString();
        }
        private void bt_shoes1_Click_1(object sender, EventArgs e)
        {
            int tax;
            bool exists = false;
            int price = 2320000;
            foreach (DataGridViewRow row in dgv_clothing.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Air Max 97")
                {
                    exists = true;
                    int currentQuantity = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[0].Value = currentQuantity + 1;

                    totals = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[3].Value = totals * price;
                    break;
                }
            }
            if (exists == false)
            {
                dt.Rows.Add(1, "Air Max 97", "Rp 2.320.000", price);
            }
            tampunganTotal = totalPrice += price;
            tax = totalPrice / 10;
            tb_subtotal.Text = (tampunganTotal.ToString());
            tb_total.Text = (tampunganTotal + tax).ToString();
        }

        private void bt_shoes2_Click_1(object sender, EventArgs e)
        {
            int tax;
            bool exists = false;
            int price = 1650000;
            foreach (DataGridViewRow row in dgv_clothing.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Air Jordan")
                {
                    exists = true;
                    int currentQuantity = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[0].Value = currentQuantity + 1;

                    totals = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[3].Value = totals * price;
                    break;
                }
            }
            if (exists == false)
            {
                dt.Rows.Add(1, "Air Jordan", "Rp 1.650.000", price);
            }
            tampunganTotal = totalPrice += price;
            tax = totalPrice / 10;
            tb_subtotal.Text = (tampunganTotal.ToString());
            tb_total.Text = (tampunganTotal + tax).ToString();
        }

        private void bt_shoes3_Click_1(object sender, EventArgs e)
        {
            int tax;
            bool exists = false;
            int price = 1475000;
            foreach (DataGridViewRow row in dgv_clothing.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Air Force 1")
                {
                    exists = true;
                    int currentQuantity = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[0].Value = currentQuantity + 1;

                    totals = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[3].Value = totals * price;
                    break;
                }
            }
            if (exists == false)
            {
                dt.Rows.Add(1, "Air Force 1", "Rp 1.475.000", price);
            }
            tampunganTotal = totalPrice += price;
            tax = totalPrice / 10;
            tb_subtotal.Text = (tampunganTotal.ToString());
            tb_total.Text = (tampunganTotal + tax).ToString();
        }

       
        private void bt_acc1_Click_1(object sender, EventArgs e)
        {
            int tax;
            bool exists = false;
            int price = 380000;
            foreach (DataGridViewRow row in dgv_clothing.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Ruby Earrings")
                {
                    exists = true;
                    int currentQuantity = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[0].Value = currentQuantity + 1;

                    totals = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[3].Value = totals * price;
                    break;
                }
            }
            if (exists == false)
            {
                dt.Rows.Add(1, "Ruby Earrings", "Rp 380.000", price);
            }
            tampunganTotal = totalPrice += price;
            tax = totalPrice / 10;
            tb_subtotal.Text = (tampunganTotal.ToString());
            tb_total.Text = (tampunganTotal + tax).ToString();
        }

        private void bt_acc2_Click_1(object sender, EventArgs e)
        {
            int tax;
            bool exists = false;
            int price = 850000;
            foreach (DataGridViewRow row in dgv_clothing.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Sapphire Ring")
                {
                    exists = true;
                    int currentQuantity = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[0].Value = currentQuantity + 1;

                    totals = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[3].Value = totals * price;
                    break;
                }
            }
            if (exists == false)
            {
                dt.Rows.Add(1, "Sapphire Ring", "Rp 850.000", price);
            }
            tampunganTotal = totalPrice += price;
            tax = totalPrice / 10;
            tb_subtotal.Text = (tampunganTotal.ToString());
            tb_total.Text = (tampunganTotal + tax).ToString();
        }

        private void bt_acc3_Click_1(object sender, EventArgs e)
        {
            int tax;
            bool exists = false;
            int price = 775000;
            foreach (DataGridViewRow row in dgv_clothing.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Gold Necklace")
                {
                    exists = true;
                    int currentQuantity = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[0].Value = currentQuantity + 1;

                    totals = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[3].Value = totals * price;
                    break;
                }
            }
            if (exists == false)
            {
                dt.Rows.Add(1, "Gold Necklace", "Rp 775.000", price);
            }
            tampunganTotal = totalPrice += price;
            tax = totalPrice / 10;
            tb_subtotal.Text = (tampunganTotal.ToString());
            tb_total.Text = (tampunganTotal + tax).ToString();
        }
        private void bt_upload_Click_1(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Image Files (*.jpg, *.png, *bmp)|*.jpg; *.png; *.bmp|All Files(.)|*.*";
            ofd.Multiselect = true;
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                pb_upload.Image = Image.FromFile(ofd.FileName);
                tb_itemname.Enabled = true;
                tb_itemprice.Enabled = true;
            }
        }

        private void bt_addtocart_Click_1(object sender, EventArgs e)
        {
            int price = Convert.ToInt32(tb_itemprice.Text);
            int tax;
            bool exists = false;

            foreach (DataGridViewRow row in dgv_clothing.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == tb_itemname.Text)
                {
                    exists = true;
                    int currentQuantity = Convert.ToInt32(row.Cells[0].Value); 
                    row.Cells[0].Value = currentQuantity + 1;
                    totals = Convert.ToInt32(row.Cells[0].Value) * Convert.ToInt32(tb_itemprice.Text);
                    row.Cells[3].Value = totals;
                    break;
                }
            }
            if (!exists)
            {
                dt.Rows.Add(1, tb_itemname.Text, tb_itemprice.Text, tb_itemprice.Text);
            }
            tampunganTotal = totalPrice += price;
            tax = totalPrice / 10;
            tb_subtotal.Text = (tampunganTotal.ToString());
            tb_total.Text = (tampunganTotal + tax).ToString();
        }

        private void tShirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            p_tshirt.Visible = true;
            p_shirt.Visible = false;
            p_pants.Visible = false;
            p_long.Visible = false;
            p_shoes.Visible = false;
            p_jewel.Visible = false;
            p_others.Visible = false;
        }

        private void shirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            p_tshirt.Visible = false;
            p_shirt.Visible = true;
            p_pants.Visible = false;
            p_long.Visible = false;
            p_shoes.Visible = false;
            p_jewel.Visible = false;
            p_others.Visible = false;
        }

        private void pantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            p_tshirt.Visible = false;
            p_shirt.Visible = false;
            p_pants.Visible = true;
            p_long.Visible = false;
            p_shoes.Visible = false;
            p_jewel.Visible = false;
            p_others.Visible = false;
        }

        private void longPantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            p_tshirt.Visible = false;
            p_shirt.Visible = false;
            p_pants.Visible = false;
            p_long.Visible = true;
            p_shoes.Visible = false;
            p_jewel.Visible = false;
            p_others.Visible = false;
        }

        private void shoesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            p_tshirt.Visible = false;
            p_shirt.Visible = false;
            p_pants.Visible = false;
            p_long.Visible = false;
            p_shoes.Visible = true;
            p_jewel.Visible = false;
            p_others.Visible = false;
        }

        private void jewelleriesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            p_tshirt.Visible = false;
            p_shirt.Visible = false;
            p_pants.Visible = false;
            p_long.Visible = false;
            p_shoes.Visible = false;
            p_jewel.Visible = true;
            p_others.Visible = false;
        }

        private void otherToolStripMenuItem_Click(object sender, EventArgs e)
        {
            p_tshirt.Visible = false;
            p_shirt.Visible = false;
            p_pants.Visible = false;
            p_long.Visible = false;
            p_shoes.Visible = false;
            p_jewel.Visible = false;
            p_others.Visible = true;
        }

        private void bt_delete_Click(object sender, EventArgs e)
        {
           if (baris >= 0 & dt.Rows.Count > 0)
            {
                dt.Rows.RemoveAt(baris);
                dgv_clothing.DataSource = dt;

                int subtotal = 0;
                for (int i = 0;  i < dt.Rows.Count; i++)
                {
                    subtotal += Convert.ToInt32(dt.Rows[i]["Total"]);
                }
                tb_subtotal.Text = "Rp. " + subtotal.ToString("#,0.") + ".";

                double total = subtotal + subtotal * 0.1;
                tb_total.Text = "Rp. " + total.ToString("#,0.") + ".";
            }
        }

        private void tb_itemprice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tb_itemprice_TextChanged(object sender, EventArgs e)
        {
            if (tb_itemprice.Text == "" && tb_itemname.Text == "")
            {
                bt_addtocart.Enabled = false;
            }
            else
            {
                bt_addtocart.Enabled = true;
            }
        }

        private void dgv_clothing_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            index = e.RowIndex;
        }
    }
}
